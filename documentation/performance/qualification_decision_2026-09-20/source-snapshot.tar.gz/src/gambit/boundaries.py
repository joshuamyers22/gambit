"""Validation contracts at user callback and backtest execution boundaries."""

from __future__ import annotations

import math
from collections.abc import Iterable
from typing import Any, cast

import numpy as np


class BacktestCallbackError(RuntimeError):
    """Add stable execution context while retaining the original exception cause."""


def checked_finite_float(value: Any, *, label: str) -> float:
    """Return a binary64 value or fail before non-finite arithmetic is published."""
    try:
        result = float(value)
    except (OverflowError, TypeError, ValueError) as exc:
        raise OverflowError(f"{label} exceeded the finite binary64 range") from exc
    if not math.isfinite(result):
        raise OverflowError(f"{label} exceeded the finite binary64 range")
    return result


def checked_fsum(values: Iterable[float], *, label: str) -> float:
    """Accumulate finite financial values without silently returning infinity."""
    try:
        result = math.fsum(values)
    except (OverflowError, ValueError) as exc:
        raise OverflowError(f"{label} exceeded the finite binary64 range") from exc
    return checked_finite_float(result, label=label)


def validate_date_range(
    start: str | np.datetime64 | None,
    end: str | np.datetime64 | None,
    *,
    owner: str,
) -> tuple[np.datetime64, np.datetime64]:
    """Normalize optional date bounds and reject reversed ranges."""
    try:
        start_timestamp = np.datetime64("NaT", "ns") if start is None else np.datetime64(start)
        end_timestamp = np.datetime64("NaT", "ns") if end is None else np.datetime64(end)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{owner} date range contains an invalid timestamp") from exc
    if not np.isnat(start_timestamp) and not np.isnat(end_timestamp) and start_timestamp > end_timestamp:
        raise ValueError(f"{owner} start date cannot be after end date")
    return start_timestamp, end_timestamp


def final_timestamp_at_or_before(
    timestamps: np.ndarray,
    end: np.datetime64,
) -> np.datetime64 | None:
    """Return the last grid timestamp inside an optional inclusive end bound."""
    if np.isnat(end):
        return cast(np.datetime64, timestamps[-1])
    index = int(np.searchsorted(timestamps, end, side="right")) - 1
    if index < 0:
        return None
    return cast(np.datetime64, timestamps[index])


def validate_timestamp_grid(timestamps: np.ndarray, *, owner: str) -> None:
    """Require a non-empty, one-dimensional, strictly increasing datetime grid."""
    if not isinstance(timestamps, np.ndarray):
        raise TypeError(f"{owner} timestamps must be a NumPy array")
    if timestamps.ndim != 1:
        raise ValueError(f"{owner} timestamps must be one-dimensional")
    if not np.issubdtype(timestamps.dtype, np.datetime64):
        raise TypeError(f"{owner} timestamps must have a datetime64 dtype")
    if timestamps.size == 0:
        raise ValueError(f"{owner} timestamps cannot be empty")
    normalized: np.ndarray = timestamps.astype("datetime64[ns]")
    if np.isnat(normalized).any():
        raise ValueError(f"{owner} timestamps cannot contain NaT")
    if not bool(np.all(np.diff(normalized.astype(np.int64)) > 0)):
        raise ValueError(f"{owner} timestamps must be strictly increasing and unique")


def validate_strategy_timestamps(timestamps: np.ndarray) -> None:
    validate_timestamp_grid(timestamps, owner="strategy")


def timestamp_index(timestamps: np.ndarray, timestamp: np.datetime64, *, owner: str) -> int:
    """Resolve an exact timestamp without leaking an array bounds error."""
    index = int(np.searchsorted(timestamps, timestamp))
    if index >= len(timestamps) or timestamps[index] != timestamp:
        raise ValueError(f"timestamp {timestamp} is not present in the {owner} timestamp grid")
    return index


def validate_price_value(
    value: Any,
    *,
    symbol: str,
    timestamp: np.datetime64,
    source: str,
    allow_missing: bool = True,
) -> float:
    """Coerce a real scalar price and distinguish missing from invalid values."""
    if isinstance(value, (bool, np.bool_)) or not isinstance(
        value, (int, float, np.integer, np.floating)
    ):
        raise TypeError(
            f"{source} returned a non-real scalar price for {symbol} at {timestamp}: {value!r}"
        )
    price = float(value)
    if math.isnan(price):
        if allow_missing:
            return price
        raise ValueError(f"{source} returned a missing price for {symbol} at {timestamp}")
    if not math.isfinite(price):
        raise ValueError(f"{source} returned a non-finite price for {symbol} at {timestamp}: {price}")
    return price
