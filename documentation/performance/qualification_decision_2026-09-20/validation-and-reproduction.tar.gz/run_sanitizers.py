import hashlib,json,os,subprocess,sys
from pathlib import Path
repo=Path('/Users/jkm0607/Projects/gambit'); root=repo.parent/'gambit-evidence/lat09-2026-09-20'
sys.path.insert(0,str(repo/'benchmarks'))
from replay_input import build
library=build(root/'sanitized-input',sanitize=True)
bootstrap=root/'asan_bootstrap.py'
bootstrap.write_text('''import os, sys, pytest, gambit._factor_cache as native
os.environ['DYLD_INSERT_LIBRARIES']='/Library/Developer/CommandLineTools/usr/lib/clang/17/lib/darwin/libclang_rt.asan_osx_dynamic.dylib'
assert '/lat09-2026-09-20/sanitized/src/' in native.__file__, native.__file__
print('SANITIZED_NATIVE',native.__file__,flush=True)
sys.exit(pytest.main(['-q','tests/test_top_of_book_backtest.py','tests/test_fifo_backtest.py','tests/test_fifo_parity.py','tests/test_tick_ring.py','tests/test_replay_input.py','tests/test_controlled_handoff.py']))
''')
env={**os.environ,'PYTHONPATH':str(root/'sanitized/src'),'DYLD_INSERT_LIBRARIES':'/Library/Developer/CommandLineTools/usr/lib/clang/17/lib/darwin/libclang_rt.asan_osx_dynamic.dylib','ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1:quarantine_size_mb=16','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1','GAMBIT_INPUT_TEST_LIBRARY':str(library),'GAMBIT_SANITIZER_RUN':'1'}
with (root/'sanitized-tests.log').open('w') as log:
 result=subprocess.run([sys.executable,str(bootstrap)],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
assert result.returncode==0,'sanitized tests failed; retained log'
command=['c++','-std=c++11','-O1','-g','-Wall','-Wextra','-Wpedantic','-Werror','-fsanitize=thread','-fno-omit-frame-pointer','-pthread','-Isrc/gambit/cpp/factor_cache','tests/cpp/tick_ring_tsan.cpp','-o',str(root/'tick-ring-tsan')]
with (root/'tsan-build.log').open('w') as log: subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
with (root/'tsan-run.log').open('w') as log:
 result=subprocess.run([str(root/'tick-ring-tsan')],env={**os.environ,'TSAN_OPTIONS':'halt_on_error=1:second_deadlock_stack=1'},stdout=log,stderr=subprocess.STDOUT,timeout=120)
(root/'tsan-result.json').write_text(json.dumps(dict(command=command,returncode=result.returncode,binary_sha256=hashlib.sha256((root/'tick-ring-tsan').read_bytes()).hexdigest(),record_count=1800000,scope='standalone SPSC primitive; not Python wrapper TSan'),indent=2)+'\n')
assert result.returncode==0,'TSan failed; retained log'
print('ASan/UBSan and standalone TSan completed')
