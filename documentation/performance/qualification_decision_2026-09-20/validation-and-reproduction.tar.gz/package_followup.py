import json,os,subprocess
from pathlib import Path
repo=Path('/Users/jkm0607/Projects/gambit');root=repo.parent/'gambit-evidence/lat09-2026-09-20'
results=json.loads((root/'package-matrix.json').read_text()); results['312']['offline_attempt']=dict(status=results['312']['status'],error=results['312']['error'])
for label in ('312','sdist'):
 out=root/('package-'+label);out.mkdir(exist_ok=True)
 commands=[]
 def run(args,timeout=300):
  commands.append(args)
  with (out/'followup.log').open('a') as log:
   log.write('COMMAND '+json.dumps(args)+'\n');log.flush()
   subprocess.run(args,cwd=out,env={**os.environ,'UV_OFFLINE':'1'},stdout=log,stderr=subprocess.STDOUT,timeout=timeout,check=True)
 try:
  py=out/'env/bin/python'
  if label=='sdist':
   run(['uv','venv','--python',str(repo/'.venv/bin/python'),str(out/'env')])
   run(['uv','pip','install','--python',str(py),str(repo/'dist/gambit_markets-1.1.0.tar.gz'),'pytest'])
  run([str(py),'-c',"import gambit,gambit._factor_cache as n,sys; print(sys.version); print(gambit.__file__); print(n.__file__); assert '/lat09-2026-09-20/package-' in gambit.__file__"])
  run([str(py),str(repo/'tools/release_smoke.py')])
  run([str(out/'env/bin/gambit-factor-cache'),'--help'])
  run([str(py),'-m','pytest','-q',str(repo/'tests/test_fifo_backtest.py'),str(repo/'tests/test_top_of_book_backtest.py'),str(repo/'tests/test_tick_ring.py')])
  with (out/'installed-dependencies.txt').open('w') as log:subprocess.run(['uv','pip','freeze','--python',str(py)],stdout=log,check=True)
  results.setdefault(label,{}).update(status='pass',followup_commands=commands)
 except Exception as error:results.setdefault(label,{}).update(status='unverified',error=str(error),followup_commands=commands)
 (root/'package-matrix.json').write_text(json.dumps(results,indent=2)+'\n')
 print(label,results[label]['status'],flush=True)
