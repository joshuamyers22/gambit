import json,os,subprocess,sys
from pathlib import Path
repo=Path('/Users/jkm0607/Projects/gambit'); root=repo.parent/'gambit-evidence/lat09-2026-09-20'
runtimes={'310':repo/'.venv/bin/python','311':Path('/Users/jkm0607/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11'),'312':Path('/Users/jkm0607/.local/share/uv/python/cpython-3.12.11-macos-aarch64-none/bin/python3.12')}
results={}
for label,python in runtimes.items():
 out=root/('package-'+label);out.mkdir();commands=[]
 def run(args, timeout=300):
  commands.append(args)
  with (out/'validation.log').open('a') as log:
   log.write('COMMAND '+json.dumps(args)+'\n');log.flush()
   subprocess.run(args,cwd=out,env={**os.environ,'UV_OFFLINE':'1'},stdout=log,stderr=subprocess.STDOUT,timeout=timeout,check=True)
 try:
  if label=='310': wheel=next((repo/'dist').glob('*cp310*.whl'))
  else:
   run(['uv','build','--wheel','--python',str(python),'--out-dir',str(out/'dist'),str(repo)])
   wheel=next((out/'dist').glob('*.whl'))
  run(['uv','venv','--python',str(python),str(out/'env')])
  py=out/'env/bin/python'
  run(['uv','pip','install','--python',str(py),str(wheel),'pytest'])
  run([str(py),'-c',"import gambit,gambit._factor_cache as n,sys; print(sys.version); print(gambit.__file__); print(n.__file__); assert '/lat09-2026-09-20/package-' in gambit.__file__"])
  run([str(py),str(repo/'tools/release_smoke.py')])
  run([str(out/'env/bin/gambit-factor-cache'),'--help'])
  run([str(py),'-m','pytest','-q',str(repo/'tests/test_fifo_backtest.py'),str(repo/'tests/test_top_of_book_backtest.py'),str(repo/'tests/test_tick_ring.py')])
  results[label]=dict(status='pass',wheel=str(wheel),commands=commands)
 except Exception as error:
  results[label]=dict(status='unverified',error=str(error),commands=commands)
 (root/'package-matrix.json').write_text(json.dumps(results,indent=2)+'\n')
 print(label,results[label]['status'],flush=True)
