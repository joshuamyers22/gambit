import hashlib,json,sys
from pathlib import Path
import numpy as np
repo=Path('/Users/jkm0607/Projects/gambit');root=repo.parent/'gambit-evidence/lat09-2026-09-20'
sys.path.insert(0,str(repo/'benchmarks'))
from fifo_parity import compare_snapshot

def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
verified=[]
for directory in sorted((repo/'documentation/performance').glob('*2026-09-20')):
 path=directory/'manifest.json'
 if not path.is_file():continue
 manifest=json.loads(path.read_text())
 for section in ('artifacts','archives','validation_logs','repository_files'):
  for name,item in manifest.get(section,{}).items():
   expected=item if isinstance(item,str) else item.get('sha256')
   if not expected:continue
   artifact=directory/name
   # Historical source hashes describe their snapshots, not today's working tree.
   if section=='repository_files' and isinstance(item,str):continue
   assert artifact.is_file(),str(artifact)
   assert sha(artifact)==expected,str(artifact)
   verified.append(str(artifact.relative_to(repo)))
parity=repo.parent/'gambit-evidence/lat05-2026-09-20/parity'
manifest=json.loads((repo/'documentation/performance/fifo_optimization_2026-09-20/manifest.json').read_text())
native=sha(repo/'src/gambit/_factor_cache.cpython-310-darwin.so')
rows=[]
for directory in sorted(parity.glob('[0-9][0-9]-*')):
 for name in ('trial.json','worker-result.json','native-trace.npz','reference-trace.npz','checkpoints.jsonl'):
  path=directory/name
  expected=manifest['external_files'][str(path.relative_to(parity.parent))]['sha256']
  assert sha(path)==expected,str(path)
 worker=json.loads((directory/'worker-result.json').read_text())
 assert worker['identity']['native_extension_sha256']==native
 assert worker['identity']['files']['src/gambit/cpp/factor_cache/top_of_book_backtest.cpp']==sha(repo/'src/gambit/cpp/factor_cache/top_of_book_backtest.cpp')
 assert worker['reference_build']['source_sha256']==sha(repo/'benchmarks/fifo_reference.cpp')
 assert worker['status']=='exact_trace_match'
 with np.load(directory/'native-trace.npz',allow_pickle=False) as actual, np.load(directory/'reference-trace.npz',allow_pickle=False) as expected:
  compare_snapshot(actual,expected)
 assert sha(directory/'checkpoints.jsonl')==worker['checkpoints_sha256']
 rows.append(dict(directory=str(directory),processed=worker['workload']['ticks'],checkpoints=worker['comparison']['checkpoints'],native_sha256=native,status='preserved_trace_arrays_recompared',checkpoint_evidence='historical stream hash verified; not a fresh replay'))
result=dict(compact_artifacts_verified=len(verified),artifacts=verified,prior_trace_cases=rows,total_trace_records=sum(r['processed'] for r in rows),total_checkpoints=sum(r['checkpoints'] for r in rows),native_sha256=native,fresh_full_volume_replay=False)
(root/'prior-evidence-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('artifacts','prior_trace_cases')},indent=2))
