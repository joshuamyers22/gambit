import importlib.metadata, json, platform, shutil, sys
result=dict(machine=platform.machine(),platform=platform.platform(),python=sys.version,tools={n:shutil.which(n) for n in ['c++','g++','clang++','uv','gcc']},packages={})
for name in ['gambit-markets','numpy','pybind11','setuptools','pytest','psutil']:
 try: result['packages'][name]=importlib.metadata.version(name)
 except importlib.metadata.PackageNotFoundError: result['packages'][name]=None
print(json.dumps(result,indent=2))
