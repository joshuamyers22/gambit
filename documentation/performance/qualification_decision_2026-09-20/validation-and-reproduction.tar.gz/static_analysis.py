import json,subprocess
from pathlib import Path
root=Path('/Users/jkm0607/Projects/gambit-evidence/lat09-2026-09-20')
manifest=json.loads((root/'sanitized/build.json').read_text()); results=[]
for command in manifest['commands']:
 if '-c' not in command: continue
 args=[a for a in command[1:] if a not in ('-c','-fsanitize=address,undefined','-fno-omit-frame-pointer')]
 i=args.index('-o');del args[i:i+2]
 name=next(Path(a).stem for a in args if a.endswith('.cpp'))
 args=['clang++','--analyze','-Xanalyzer','-analyzer-output=text',*args]
 result=subprocess.run(args,capture_output=True,text=True,timeout=120)
 (root/(name+'-analyzer.log')).write_text(result.stdout+result.stderr)
 results.append(dict(source=name,command=args,returncode=result.returncode,diagnostics=result.stdout+result.stderr))
(root/'static-analysis.json').write_text(json.dumps(results,indent=2)+'\n')
print([(r['source'],r['returncode'],bool(r['diagnostics'])) for r in results])
