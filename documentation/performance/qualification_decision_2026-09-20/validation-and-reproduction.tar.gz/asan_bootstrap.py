import os, sys, pytest, gambit._factor_cache as native
os.environ['DYLD_INSERT_LIBRARIES']='/Library/Developer/CommandLineTools/usr/lib/clang/17/lib/darwin/libclang_rt.asan_osx_dynamic.dylib'
assert '/lat09-2026-09-20/sanitized/src/' in native.__file__, native.__file__
print('SANITIZED_NATIVE',native.__file__,flush=True)
sys.exit(pytest.main(['-q','tests/test_top_of_book_backtest.py','tests/test_fifo_backtest.py','tests/test_fifo_parity.py','tests/test_tick_ring.py','tests/test_replay_input.py','tests/test_controlled_handoff.py']))
