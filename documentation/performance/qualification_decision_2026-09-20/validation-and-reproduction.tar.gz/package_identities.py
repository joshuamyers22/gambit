import hashlib,json,subprocess
from pathlib import Path
repo=Path('/Users/jkm0607/Projects/gambit'); root=repo.parent/'gambit-evidence/lat09-2026-09-20'
results={}
for label in ('310','311','312','sdist'):
 out=root/('package-'+label); py=out/'env/bin/python'
 code='''import sys,json,hashlib,importlib,importlib.metadata,numpy,gambit
from pathlib import Path
modules={}
for name in ['gambit._factor_cache','gambit._io','gambit._options','gambit.compute_pnl']:
 module=importlib.import_module(name);path=Path(module.__file__);modules[name]=dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest())
print(json.dumps(dict(python=sys.version,package_path=gambit.__file__,numpy=numpy.__version__,native=modules,dependencies={d.metadata['Name']:d.version for d in importlib.metadata.distributions()})))
'''
 results[label]=json.loads(subprocess.check_output([str(py),'-c',code],cwd=out,text=True))
 wheel=next((repo/'dist' if label=='310' else out/'dist').glob('*.whl'),None) if label!='sdist' else repo/'dist/gambit_markets-1.1.0.tar.gz'
 if wheel:results[label]['artifact']=dict(path=str(wheel),sha256=hashlib.sha256(wheel.read_bytes()).hexdigest())
(root/'package-identities.json').write_text(json.dumps(results,indent=2)+'\n')
print({k:(v['python'].split()[0],v['numpy']) for k,v in results.items()})
