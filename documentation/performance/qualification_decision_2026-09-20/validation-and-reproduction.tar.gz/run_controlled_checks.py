import hashlib,json,sys
from pathlib import Path
repo=Path('/Users/jkm0607/Projects/gambit'); root=repo.parent/'gambit-evidence/lat09-2026-09-20'
sys.path.insert(0,str(repo/'benchmarks'))
from controlled_replay import run_trial
from replay_contract import workload,summarize
build=json.loads((repo.parent/'gambit-evidence/lat05-2026-09-20/candidate-build/build.json').read_text())
for name,digest in build['all_sources'].items():
 assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
(root/'retained-native-build.json').write_text(json.dumps(build,indent=2)+'\n')
trials=[]
for scenario,count in [('fifo-3y-sparse-v1',3),('fifo-2y-sparse-v1',1),('fifo-1m-dense-v1',2),('fifo-2m-dense-v1',2)]:
 for index in range(count):
  path=root/'controlled-checks'/f'{scenario}-{index+1}'
  trial=run_trial(path,workload(scenario),session_id='lat09-development-check',build_manifest=build)
  trials.append(trial)
  print(scenario,index+1,trial['status'],trial.get('measurement'),flush=True)
  (root/'controlled-checks-index.json').write_text(json.dumps([dict(path=t['trial_id'],status=t['status'],workload=t['workload']['scenario']) for t in trials],indent=2)+'\n')
  if trial['status']!='ok':raise RuntimeError('failed trial retained; no qualification')
primary=[t for t in trials if t['workload']['scenario']=='fifo-3y-sparse-v1']
(root/'primary-disposition.json').write_text(json.dumps(summarize(primary),indent=2)+'\n')
print('Complete: development checks only; no session attestation or statistical qualification.',flush=True)
