import hashlib,json,shutil,tarfile
from pathlib import Path
repo=Path('/Users/jkm0607/Projects/gambit');root=repo.parent/'gambit-evidence/lat09-2026-09-20';out=repo/'documentation/performance/qualification_decision_2026-09-20'

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def archive(p,items):
 with tarfile.open(p,'w:gz') as tar:
  for source,name in items:tar.add(source,arcname=name,recursive=False)
initial=json.loads((root/'source-inventory.json').read_text())
runtime={n:h for n,h in initial['files'].items() if n.startswith(('src/','benchmarks/','tests/','tools/','.github/')) or n in ('setup.py','pyproject.toml','uv.lock','Makefile','MANIFEST.in')}
for name,digest in runtime.items():assert sha(repo/name)==digest,name
fingerprint=hashlib.sha256(json.dumps(runtime,sort_keys=True,separators=(',',':')).encode()).hexdigest()
native=sha(repo/'src/gambit/_factor_cache.cpython-310-darwin.so');assert native=='9bb6074a0149a302edd4a1f8ab3063f3ae830b15418342738dcacfde450ffb39'
baseline=repo.parent/'gambit-evidence/lat05-2026-09-20/baseline/src/gambit/_factor_cache.cpython-310-darwin.so'
assert sha(baseline)=='593537a814f3364f384df5cb1a33df86aa8b8870edd88c020756026111d5b7d2'
for name,digest in json.loads((root/'sanitized/build.json').read_text())['sources'].items():assert sha(repo/name)==digest,name
assert json.loads((root/'sanitized-input/build.json').read_text())['source_sha256']==sha(repo/'benchmarks/fused_queue_input.cpp')
static=json.loads((root/'static-analysis.json').read_text());assert len(static)==3 and all(r['returncode']==0 and not r['diagnostics'] for r in static)
assert json.loads((root/'tsan-result.json').read_text())['returncode']==0
assert '208 passed' in (root/'sanitized-tests.log').read_text()
assert '2283 passed' in (root/'make-check.log').read_text() and 'verified 1 wheel(s)' in (root/'make-check.log').read_text()
packages=json.loads((root/'package-matrix.json').read_text());assert set(packages)=={'310','311','312','sdist'} and all(v['status']=='pass' for v in packages.values())
for label in packages:
 log=root/('package-'+label)/('followup.log' if label in ('312','sdist') else 'validation.log');assert '97 passed' in log.read_text()
trials=[json.loads(p.read_text()) for p in sorted((root/'controlled-checks').glob('*/trial.json'))]
assert len(trials)==8 and len({t['trial_id'] for t in trials})==8
by_scenario={}
for t in trials:
 assert t['status']=='ok' and t['build_attested'] and t['identity']['native_extension_sha256']==native
 assert t['supervisor']['shutdown']['status']=='exited'
 for key,name in [('runner_sha256','controlled_replay.py'),('contract_code_sha256','replay_contract.py'),('generator_sha256','top_of_book_backtest.py'),('input_reader_sha256','replay_input.py'),('batch_metrics_sha256','batch_metrics.py')]:assert t['identity'][key]==sha(repo/'benchmarks'/name)
 by_scenario.setdefault(t['workload']['scenario'],[]).append(t)
for scenario,rows in by_scenario.items():
 prior=next((repo.parent/'gambit-evidence/lat05-2026-09-20/parity').glob('*'+scenario+'-65521'))
 controls=json.loads((prior/'worker-result.json').read_text())['controls']
 assert all(t['measurement']['controls']==controls for t in rows),scenario
summary=json.loads((root/'primary-disposition.json').read_text());assert summary['timing_gate']=='ineligible' and summary['trials']==3
review=dict(schema='gambit-lat09-disposition-v1',review_status='complete',disposition='remain_experimental',engineering_performance_qualified=False,production_promoted=False,contract_changed=False,contract='gambit-fifo-latency-v1',authority=dict(engineering_disposition='Codex under user request to finish LAT-09',product_repository_authority='Josh Myers',independent_signoff_recorded=False),source=dict(base_revision=initial['revision'],working_tree_dirty=True,committed_release_candidate=False,runtime_source_fingerprint=fingerprint,runtime_files=len(runtime),runtime_sources_unchanged_during_review=True,native_sha256=native),validation=dict(make_check_tests=2283,asan_ubsan_tests=208,asan_leak_detection=False,asan_quarantine_mib=16,tsan_records=1800000,tsan_scope='standalone SPSC primitive on macOS ARM64',clang_translation_units=3,clang_diagnostics=0,installed_native_tests_per_environment=97,installed_environments=['macOS ARM64 CPython 3.10.20 wheel','macOS ARM64 CPython 3.11.15 wheel','macOS ARM64 CPython 3.12.11 wheel','macOS ARM64 CPython 3.10.20 sdist'],supported_linux_x86_64_tested=False),prior_evidence=json.loads((root/'prior-evidence-audit.json').read_text()),controlled_checks=dict(successful_workers=8,measured_records=sum(t['workload']['ticks'] for t in trials),all_reviewed_controls_match=True,primary=summary,qualification_campaign_executed=False),retained=dict(original_ring=True,legacy_input_default=True,fifo_specialization='experimental',fused_input='explicit experimental option',detailed_batch_diagnostics='opt-in diagnosis only'),open_gates=['reviewed committed release candidate and source/build mapping','supported-platform release evidence including Linux x86-64 and repaired distributable wheels','full-volume primary instrumentation overhead review','four attested independent sessions of 50 full primary trials on observable approved host','representative production corpus/strategy, calibrated semantics and cold/warm decode/storage evidence','named independent review and final promotion acceptance'],rollback_runbook='documentation/operations/replay_qualification.md',lat10='not started; requires separately approved concrete requirement')
assert review['controlled_checks']['measured_records']==3478416000
write(root/'decision.json',review)
write(root/'runtime-source-identity.json',dict(fingerprint=fingerprint,files=runtime,base_revision=initial['revision'],dirty=True,excluded_unrelated_document='GAMBIT_MCP_PROJECT_PLAN.md'))
for name in ('decision.json','runtime-source-identity.json','primary-disposition.json','prior-evidence-audit.json','package-matrix.json','package-identities.json','static-analysis.json','tsan-result.json','retained-native-build.json','linux-probe.json'):
 shutil.copyfile(root/name,out/name)
raw=[p for p in sorted((root/'controlled-checks').rglob('*')) if p.is_file()]
archive(out/'controlled-checks.tar.gz',[(p,str(p.relative_to(root))) for p in raw])
records=[p for p in sorted(root.iterdir()) if p.is_file() and p.suffix in ('.json','.log','.py','.txt')]
records += [p for label in packages for p in sorted((root/('package-'+label)).iterdir()) if p.is_file() and p.suffix in ('.json','.log','.txt')]
records += [root/'sanitized/build.json',root/'sanitized-input/build.json',root/'sanitized-input/compiler.log']
archive(out/'validation-and-reproduction.tar.gz',[(p,str(p.relative_to(root))) for p in records])
docs=['LATENCY_INFRASTRUCTURE_PROJECT_PLAN.md','PRODUCTION_READINESS_PLAN.md','LATENCY_BUDGET.md','documentation/architecture/adr_native_tick_replay.md','documentation/operations/replay_qualification.md','documentation/performance/qualification_decision_2026-09-20.md']
archive(out/'source-snapshot.tar.gz',[(repo/name,name) for name in sorted(set(runtime)|set(docs))])
selected=records+raw+[root/'tick-ring-tsan',root/'sanitized/src/gambit/_factor_cache.cpython-310-darwin.so',root/'sanitized-input/queue_input.dylib']
package_ids=json.loads((root/'package-identities.json').read_text())
for item in package_ids.values():
 selected.append(Path(item['artifact']['path']))
 selected += [Path(m['path']) for m in item['native'].values()]
write(out/'external-evidence-manifest.json',dict(scope='Selected reproducibility records, installed native binaries and package artifacts; disposable environments/object files excluded',files={str(p):dict(sha256=sha(p),bytes=p.stat().st_size) for p in sorted(set(selected))}))
(out/'README.md').write_text('''# LAT-09 evidence and disposition\n\nSee the [review](../qualification_decision_2026-09-20.md) and [runbook](../../operations/replay_qualification.md).\n\n**Remain experimental.** Review complete; statistical performance and production qualification not achieved.\n\n- `decision.json`: explicit disposition, authority/scope, checks, retained defaults and unmet gates.\n- `runtime-source-identity.json`: executable/build/test source fingerprint, unchanged through validation; dirty working-tree evidence, not a clean release commit.\n- `controlled-checks.tar.gz`: eight fresh supervised observations, with raw requests, worker results, stderr and watchdog reports.\n- `primary-disposition.json`: three full primary observations; timing gate ineligible.\n- `prior-evidence-audit.json`: 173 compact artifact hashes verified; six preserved trace-array pairs re-compared, with checkpoint hashes and matching native identity. Not a fresh oracle replay.\n- `package-*`, `static-analysis.json`, `tsan-result.json`, `linux-probe.json`, `retained-native-build.json`: scoped platform and build records. The Linux probe is ARM64 environment discovery only.\n- `validation-and-reproduction.tar.gz`: scripts and logs, including the failed offline Python 3.12 install and successful follow-up, sanitizer records and full check output.\n- `source-snapshot.tar.gz`: content-identified runtime/build/test files and final review documents.\n- `external-evidence-manifest.json`: selected external artifacts/binaries and package hashes; disposable environments remain outside the repository.\n- `manifest.json`: bundle and final document hashes.\n\nNo thresholds, maturity classifiers, default ring, loader or runtime implementation changed. No commit, release or deployment was performed.\n''')
write(out/'manifest.json',dict(schema='gambit-lat09-bundle-v1',artifacts={p.name:dict(sha256=sha(p),bytes=p.stat().st_size) for p in sorted(out.iterdir()) if p.name!='manifest.json'},review_documents={n:sha(repo/n) for n in docs},runtime_source_fingerprint=fingerprint))
manifest=json.loads((out/'manifest.json').read_text());assert all(sha(out/n)==v['sha256'] for n,v in manifest['artifacts'].items())
print(json.dumps(dict(disposition=review['disposition'],runtime_source_files=len(runtime),runtime_source_fingerprint=fingerprint,controlled_workers=len(trials),measured_records=review['controlled_checks']['measured_records'],bundle_bytes=sum(p.stat().st_size for p in out.iterdir()),hashes_verified=True),indent=2))
