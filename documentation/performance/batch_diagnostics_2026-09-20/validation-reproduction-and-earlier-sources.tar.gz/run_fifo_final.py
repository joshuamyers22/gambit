import json
import sys
from pathlib import Path
import numpy as np
repo=Path('/Users/jkm0607/Projects/gambit')
sys.path.insert(0,str(repo/'benchmarks'))
from controlled_replay import run_trial
from replay_contract import workload, distribution
root=repo.parent/'gambit-evidence/lat08-2026-09-20'
for name, scenario, ticks in [('fifo-final-10m-prefix','fifo-3y-sparse-v1',10000000),('fifo-final-dense-2m','fifo-2m-dense-v1',None)]:
    spec=workload(scenario)
    out=root/name
    out.mkdir()
    rows=[]
    identities=[]
    for i in range(30):
        row={}
        for enabled in ((False,True) if i%2==0 else (True,False)):
            mode='on' if enabled else 'off'
            options=dict(batch_metrics=enabled)
            if ticks is not None: options['prefix_ticks']=ticks
            trial=run_trial(out/f'{i:02d}-{mode}',spec,session_id=name,diagnostic=options)
            assert trial['status']=='ok',trial
            identity={k:v for k,v in trial['identity'].items() if k!='dirty_state'}
            identities.append(json.dumps(identity,sort_keys=True))
            row[mode]=trial
        assert row['off']['measurement']['controls']==row['on']['measurement']['controls']
        rows.append(row)
        print(name,'pair',i+1,flush=True)
    assert len(set(identities))==1
    result={}
    for metric in ('execution_seconds','harness_seconds','cpu_seconds','peak_rss_bytes'):
        off=np.array([r['off']['measurement'][metric] for r in rows],dtype=float)
        on=np.array([r['on']['measurement'][metric] for r in rows],dtype=float)
        effects=on/off-1
        rng=np.random.default_rng(20260920)
        interval=np.percentile(np.median(rng.choice(effects,(10000,30)),axis=1),[2.5,97.5]).tolist()
        result[metric]=dict(off=distribution(off.tolist()),on=distribution(on.tolist()),median_relative_overhead=float(np.median(effects)),bootstrap_95_interval=interval,one_percent_target='within' if interval[1]<=.01 else 'exceeds' if interval[0]>.01 else 'inconclusive')
    (out/'summary.json').write_text(json.dumps(dict(pairs=30,diagnostic_only=True,performance_qualification=False,workload=spec,measured_ticks=ticks or spec['ticks'],identity=json.loads(identities[0]),metrics=result),indent=2)+'\n')
