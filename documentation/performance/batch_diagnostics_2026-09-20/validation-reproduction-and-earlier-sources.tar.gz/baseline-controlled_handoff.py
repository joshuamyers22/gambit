"""Bounded, paired engineering measurements of the public concurrent factor path.

Run workers through separate Python environments to compare native builds. Arrival
probes are batch-completion observations, not per-record native timestamps.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import os
import platform
import queue
import resource
import subprocess
import sys
import threading
import time
from pathlib import Path

import numpy as np

from gambit.factor_cache import TickFactorProcessor, TickRing

try:
    from .tick_ring_benchmark import make_ticks
except ImportError:
    from tick_ring_benchmark import make_ticks


def percentiles(values):
    return dict(zip(("p50", "p95", "p99", "max"), map(float, np.percentile(values, [50, 95, 99, 100]))))


def measure(records, *, path="in_place", batch=1024, capacity=65536, rate=0,
            stall_seconds=0.0, probes=False, timeout=30.0):
    """Time a complete drain with bounded workers and exact direct-factor parity.

    Scheduled offers never move when admission blocks. No offered records are
    skipped: admission waits for capacity and all records must reach the factors.
    The separate ring tests exercise reject-newest rather than retry semantics.
    """
    count = len(records)
    if count < 1 or batch < 1 or batch > capacity or rate < 0 or timeout <= 0:
        raise ValueError("invalid workload bounds")
    if path not in ("in_place", "copy", "lease", "direct"):
        raise ValueError("unknown consumer path")
    reference = TickFactorProcessor()
    reference.process_batch(records)
    expected = reference.snapshot
    processor = TickFactorProcessor()
    ring = TickRing(capacity)
    start = threading.Event()
    stop = threading.Event()
    errors = queue.Queue()
    completions = []
    enqueued = np.zeros((count + batch - 1) // batch, dtype=np.int64)
    high_water = 0
    admission_waits = 0
    epoch = 0
    deadline = 0

    def check():
        if stop.is_set() or time.perf_counter_ns() > deadline:
            raise TimeoutError("handoff worker stopped or exceeded its deadline")

    def produce():
        nonlocal high_water, admission_waits
        for offset in range(0, count, batch):
            check()
            if rate:
                scheduled = epoch + int(offset / rate * 1e9)
                while (remaining := scheduled - time.perf_counter_ns()) > 0:
                    check()
                    time.sleep(min(remaining / 1e9, 0.001))
            end = min(offset + batch, count)
            while ring.capacity - ring.depth < end - offset:
                admission_waits += 1
                check()
                time.sleep(0)
            if probes:
                enqueued[offset // batch] = time.perf_counter_ns()
            if ring.push_batch(records[offset:end]) != end - offset:
                raise RuntimeError("unexpected partial acceptance")
            if probes:
                high_water = max(high_water, ring.depth)
        ring.close()

    def consume():
        consumed = 0
        stalled = False
        while consumed < count:
            check()
            if stall_seconds and not stalled and consumed >= count // 4:
                time.sleep(stall_seconds)
                stalled = True
            if path == "in_place":
                received = ring.wait_process_batch(processor, batch, spin_count=256, timeout_seconds=0.01)
            elif path == "copy":
                values = ring.wait_pop_batch(batch, spin_count=256, timeout_seconds=0.01)
                received = len(values)
                processor.process_batch(values)
            else:
                lease = ring.wait_lease_batch(batch, spin_count=256, timeout_seconds=0.01)
                values = lease.values
                received = len(values)
                processor.process_batch(values)
                del values
                lease.close()
            if received and probes:
                completions.append((consumed, consumed + received, time.perf_counter_ns()))
            consumed += received

    def guarded(function):
        start.wait()
        try:
            function()
        except BaseException as exc:
            errors.put(exc)
            stop.set()
            ring.close()

    threads = [] if path == "direct" else [
        threading.Thread(target=guarded, args=(f,), daemon=True) for f in (produce, consume)
    ]
    for thread in threads:
        thread.start()
    before = resource.getrusage(resource.RUSAGE_SELF)
    cpu = time.process_time_ns()
    epoch = time.perf_counter_ns()
    deadline = epoch + int(timeout * 1e9)
    start.set()
    if path == "direct":
        for offset in range(0, count, batch):
            processor.process_batch(records[offset:offset + batch])
    else:
        for thread in threads:
            thread.join(max(0, (deadline - time.perf_counter_ns()) / 1e9))
        if any(thread.is_alive() for thread in threads):
            stop.set()
            ring.close()
            raise TimeoutError("handoff threads did not finish")
        if not errors.empty():
            raise errors.get()
    wall_ns = time.perf_counter_ns() - epoch
    cpu_ns = time.process_time_ns() - cpu
    after = resource.getrusage(resource.RUSAGE_SELF)
    snapshot = processor.snapshot
    if snapshot != expected or snapshot["processed"] != count or snapshot["sequence_errors"]:
        raise AssertionError("complete factor snapshot differs from direct processing")
    metrics = ring.metrics
    if path != "direct" and (metrics["pushed"] != count or metrics["popped"] != count
                             or metrics["dropped"] or metrics["depth"]):
        raise AssertionError("handoff lost, rejected, or retained records")
    result = dict(path=path, count=count, batch=batch, capacity=capacity, rate=rate,
                  stall_seconds=stall_seconds, probes=probes, wall_ns=wall_ns, cpu_ns=cpu_ns,
                  peak_rss_bytes=after.ru_maxrss * (1 if sys.platform == "darwin" else 1024),
                  minor_faults=after.ru_minflt - before.ru_minflt,
                  major_faults=after.ru_majflt - before.ru_majflt,
                  voluntary_switches=after.ru_nvcsw - before.ru_nvcsw,
                  involuntary_switches=after.ru_nivcsw - before.ru_nivcsw,
                  sampled_high_water=high_water if probes else None,
                  admission_waits=admission_waits, metrics=metrics, snapshot=snapshot)
    if probes and path != "direct":
        finished = np.empty(count, dtype=np.int64)
        for begin, end, stamp in completions:
            finished[begin:end] = stamp
        batch_indices = np.arange(count) // batch
        result["enqueue_call_to_completion_ns"] = percentiles(finished - enqueued[batch_indices])
        if rate:
            scheduled = epoch + (batch_indices * batch / rate * 1e9).astype(np.int64)
            result["scheduled_to_completion_ns"] = percentiles(finished - scheduled)
            result["admission_lateness_ns"] = percentiles(enqueued[batch_indices] - scheduled)
            result["drain_after_last_offer_ns"] = int(finished[-1] - scheduled[-1])
    return result


def worker(scale=1.0):
    import gambit._factor_cache as native

    records = make_ticks(max(8192, int(8_000_000 * scale)))
    # All builds use the same warmup and the same full snapshot comparison.
    measure(records[:8192])
    scenarios = [
        ("saturated", len(records), {}),
        ("saturated_probes", len(records), dict(probes=True)),
        ("direct", len(records), dict(path="direct")),
        ("copy", min(len(records), 262144), dict(path="copy")),
        ("lease", min(len(records), 262144), dict(path="lease")),
        ("producer_limited", min(len(records), 262144), dict(rate=1_000_000, probes=True)),
        ("burst_2x", min(len(records), 262144), dict(rate=2_000_000, probes=True)),
        ("consumer_stall", min(len(records), 262144),
         dict(rate=2_000_000, capacity=2048, stall_seconds=0.01, probes=True)),
    ]
    return dict(schema=1, python=sys.version, platform=platform.platform(), machine=platform.machine(),
                native_path=native.__file__, native_sha256=hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest(),
                input_sha256=hashlib.sha256(records.tobytes()).hexdigest(),
                cases={name: measure(records[:count], **options) for name, count, options in scenarios})


def paired_summary(rows, baseline, candidate):
    rng = np.random.default_rng(606)
    result = {}
    for case in rows[0][baseline]["cases"]:
        result[case] = {}
        for field in ("wall_ns", "cpu_ns", "peak_rss_bytes"):
            a = np.array([row[baseline]["cases"][case][field] for row in rows], dtype=float)
            b = np.array([row[candidate]["cases"][case][field] for row in rows], dtype=float)
            reduction = 1 - b / a
            bootstrap = np.median(rng.choice(reduction, (10000, len(rows))), axis=1)
            result[case][field] = dict(baseline=percentiles(a), candidate=percentiles(b),
                                      median_paired_reduction=float(np.median(reduction)),
                                      bootstrap_95_ci=list(map(float, np.percentile(bootstrap, [2.5, 97.5]))))
    return result


def campaign(variants, output, trials=30, scale=1.0):
    if trials < 1 or len(variants) < 2 or len(variants) != len(set(variants)):
        raise ValueError("at least two distinct builds and one trial required")
    output.mkdir(parents=True, exist_ok=False)
    orders = list(itertools.permutations(variants))
    rows = []
    script = str(Path(__file__).resolve())
    for trial in range(trials):
        row = {}
        order = orders[trial % len(orders)]
        for name in order:
            completed = subprocess.run([variants[name], script, "worker", "--scale", str(scale)],
                                       capture_output=True, text=True, timeout=300, check=True,
                                       env={**os.environ, "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1"})
            row[name] = json.loads(completed.stdout)
        if len({item["input_sha256"] for item in row.values()}) != 1:
            raise AssertionError("builds processed different inputs")
        for case in next(iter(row.values()))["cases"]:
            snapshots = [item["cases"][case]["snapshot"] for item in row.values()]
            if any(snapshot != snapshots[0] for snapshot in snapshots):
                raise AssertionError("cross-build factor mismatch")
        rows.append(row)
        (output / f"trial-{trial:02d}.json").write_text(json.dumps(dict(order=order, results=row), indent=2) + "\n")
        print(f"completed trial {trial + 1}/{trials}", flush=True)
    names = list(variants)
    summary = dict(trials=trials, scale=scale, variants=variants,
                   harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                   comparisons={name: paired_summary(rows, names[0], name) for name in names[1:]})
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    single = sub.add_parser("worker")
    single.add_argument("--scale", type=float, default=1.0)
    compare = sub.add_parser("campaign")
    compare.add_argument("--variant", action="append", required=True, help="name=/absolute/python-or-wrapper")
    compare.add_argument("--output", type=Path, required=True)
    compare.add_argument("--trials", type=int, default=30)
    compare.add_argument("--scale", type=float, default=1.0)
    args = parser.parse_args()
    if args.scale <= 0 or args.scale > 2:
        parser.error("scale must be in (0, 2]")
    if args.command == "worker":
        print(json.dumps(worker(args.scale)))
    else:
        campaign(dict(value.split("=", 1) for value in args.variant), args.output, args.trials, args.scale)


if __name__ == "__main__":
    main()
