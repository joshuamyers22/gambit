import hashlib
import json
import shutil
import tarfile
from pathlib import Path

repo = Path('/Users/jkm0607/Projects/gambit')
root = repo.parent / 'gambit-evidence/lat08-2026-09-20'
out = repo / 'documentation/performance/batch_diagnostics_2026-09-20'

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024), b''): h.update(block)
    return h.hexdigest()

def write(path,value):
    path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')

def archive(path,items):
    with tarfile.open(path,'w:gz') as tar:
        for p,name in items: tar.add(p,arcname=name,recursive=False)

native_sha='9bb6074a0149a302edd4a1f8ab3063f3ae830b15418342738dcacfde450ffb39'
assert sha(repo/'src/gambit/_factor_cache.cpython-310-darwin.so')==native_sha
hand_names=['handoff','handoff-final']
fifo_names=['fifo-100m-prefix','fifo-dense-2m','fifo-final-10m-prefix','fifo-final-dense-2m']
measured_records=0
workers=0
cases=0
cleanup_max=0
for name in hand_names:
    rows=[json.loads(p.read_text()) for p in sorted((root/name).glob('[0-9][0-9]-*.json'))]
    assert len(rows)==60
    workers+=len(rows)
    for row in rows:
        assert row['status']=='ok' and row['native_sha256']==native_sha
        for value in row['cases'].values():
            cases+=1; measured_records+=value['count']
            assert value['status']=='ok' and value['snapshot']['processed']==value['count']
            assert value['shutdown']['status']=='joined' and not value['shutdown']['live_threads']
            cleanup_max=max(cleanup_max,value['shutdown']['cleanup_seconds'])
            m=value['metrics']
            assert m['pushed']==m['popped']==value['count'] and m['depth']==m['dropped']==0
            if row['diagnostics']:
                d=value['diagnostics']; assert d['pending_records']==0
                assert d['enqueue_to_completion']['records']==value['count']
                assert d['pending_high_water']<=d['pending_record_limit']
    summary=json.loads((root/name/'summary.json').read_text())
    for filename,digest in summary['sources'].items():
        path=(root/'measured-sources'/filename) if name=='handoff' and (root/'measured-sources'/filename).exists() else repo/'benchmarks'/filename
        assert sha(path)==digest, (name,filename)

trial_ids=set()
for name in fifo_names:
    paths=sorted((root/name).glob('*/trial.json')); assert len(paths)==60
    controls=set()
    for path in paths:
        trial=json.loads(path.read_text()); worker=json.loads(path.with_name('worker-result.json').read_text())
        assert trial['status']=='ok' and trial['identity']['native_extension_sha256']==native_sha
        assert trial['supervisor']['shutdown']['status']=='exited'
        assert trial['trial_id'] not in trial_ids; trial_ids.add(trial['trial_id'])
        controls.add(json.dumps(trial['measurement']['controls'],sort_keys=True))
        measured_records+=worker['measured_ticks']; workers+=1; cases+=1
        for key,filename in [('runner_sha256','controlled_replay.py'),('batch_metrics_sha256','batch_metrics.py')]:
            source=repo/'benchmarks'/filename if 'final' in name else root/'measured-sources'/filename
            assert sha(source)==trial['identity'][key],(name,key)
        if worker['diagnostic']['batch_metrics']:
            assert worker['batch_metrics']['records']==worker['measured_ticks']
            assert worker['batch_metrics']['total_ns']/1e9==worker['timing']['processing_seconds']
    assert len(controls)==1,name
assert (workers,cases,measured_records)==(360,960,7957286400)
for name,digest in json.loads((root/'final-source-identities.json').read_text()).items():
    assert sha(repo/name)==digest,name
names=hand_names+fifo_names
for name in names: shutil.copyfile(root/name/'summary.json',out/(name+'-summary.json'))
archive(out/'raw-trials.tar.gz',[(p,str(p.relative_to(root))) for name in names for p in sorted((root/name).rglob('*')) if p.is_file()])
record_files=[p for p in sorted(root.rglob('*')) if p.is_file() and not any(parent.name in names for parent in p.parents)]
archive(out/'validation-reproduction-and-earlier-sources.tar.gz',[(p,str(p.relative_to(root))) for p in record_files])
sources=['Makefile','LATENCY_INFRASTRUCTURE_PROJECT_PLAN.md','PRODUCTION_READINESS_PLAN.md']
sources += ['benchmarks/'+n for n in ['batch_metrics.py','batch_observability.py','controlled_handoff.py','controlled_replay.py','replay_contract.py','tick_ring_benchmark.py']]
sources += ['tests/'+n for n in ['test_batch_metrics.py','test_batch_observability.py','test_controlled_handoff.py','test_controlled_replay.py','test_replay_profiling.py']]
sources += ['documentation/'+n for n in ['operations/batch_diagnostics.md','operations/controlled_handoff.md','operations/controlled_replay.md','performance/batch_diagnostics_2026-09-20.md']]
archive(out/'final-source-snapshot.tar.gz',[(repo/name,name) for name in sources])
write(out/'decision.json',dict(task='LAT-08',status='complete for engineering acceptance',detailed_diagnostics='opt-in only',performance_qualification=False,native_unchanged=True,native_sha256=native_sha,logger_dependency_added=False,workers=workers,successful_cases=cases,measured_records=measured_records,measured_handoff_cleanup_max_seconds=cleanup_max,validation=dict(make_check_passed=True,tests=2283,focused_tests=82,new_native_sanitizer_campaign=False),final_saturated_wall_overhead=json.loads((root/'handoff-final/summary.json').read_text())['cases']['saturated']['wall_ns'],next='LAT-09 qualification and explicit promote/retarget/remain-experimental decision'))
write(out/'external-evidence-manifest.json',dict(root=str(root),files={str(p.relative_to(root)):dict(sha256=sha(p),bytes=p.stat().st_size) for p in sorted(root.rglob('*')) if p.is_file()}))
(out/'README.md').write_text('''# LAT-08 evidence\n\nSee the [report](../batch_diagnostics_2026-09-20.md) and [runbook](../../operations/batch_diagnostics.md).\n\n- `raw-trials.tar.gz`: 360 successful worker observations across six screens (960 cases), including the earlier and final-source rounds.\n- Six summary JSON files: paired results kept separate by source and workload. `handoff-final` and `fifo-final-*` match the final implementation; earlier screens retain their own source snapshot.\n- `validation-reproduction-and-earlier-sources.tar.gz`: successful full/focused/document checks, the earlier failed lease test, measurement scripts, source identities and earlier implementation snapshots.\n- `final-source-snapshot.tar.gz`: validated implementation, tests, plans and runbooks.\n- `decision.json`: diagnostic-only retention decision, scope, counts and native identity.\n- `external-evidence-manifest.json`: hashes of all external evidence.\n- `manifest.json`: hashes of this bundle and final repository sources.\n\nAll input/factor/result controls and queue accounting passed. Every worker used the unchanged native binary. No trials were pooled across the earlier/final source versions or across prefixes. Warmup and reference processing are excluded from measured record counts. No production or full-volume instrumentation qualification is claimed.\n''')
write(out/'manifest.json',dict(schema='gambit-lat08-evidence-v1',artifacts={p.name:dict(sha256=sha(p),bytes=p.stat().st_size) for p in sorted(out.iterdir()) if p.name!='manifest.json'},repository_sources={name:sha(repo/name) for name in sources}))
manifest=json.loads((out/'manifest.json').read_text())
assert all(sha(out/name)==value['sha256'] for name,value in manifest['artifacts'].items())
with tarfile.open(out/'raw-trials.tar.gz') as tar:
    assert sum(m.name.endswith('/trial.json') for m in tar.getmembers())==240
print(json.dumps(dict(workers=workers,cases=cases,measured_records=measured_records,maximum_handoff_cleanup_seconds=cleanup_max,bundle_bytes=sum(p.stat().st_size for p in out.iterdir()),source_and_evidence_hashes_verified=True,native_unchanged=True),indent=2))
