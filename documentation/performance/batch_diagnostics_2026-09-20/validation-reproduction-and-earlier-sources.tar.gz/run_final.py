import sys, subprocess
from pathlib import Path
repo=Path('/Users/jkm0607/Projects/gambit')
root=repo.parent/'gambit-evidence/lat08-2026-09-20'
sys.path.insert(0,str(repo/'benchmarks'))
from batch_observability import campaign
campaign(root/'handoff-final',30,8000000)
subprocess.run([sys.executable,str(root/'run_fifo_final.py')],check=True)
