import json
from pathlib import Path

root = Path(__file__).parent
for name in ('full-volume-overhead', 'qualification'):
    path = root / (name + '.log')
    if not path.exists():
        continue
    rows = []
    for line in path.read_text().splitlines():
        try:
            row = json.loads(line)
        except ValueError:
            continue
        if 'measurement' in row:
            rows.append(row)
    if rows:
        last = rows[-1]
        print(json.dumps(dict(campaign=name, completed=len(rows),
            failures=sum(r['status'] != 'ok' for r in rows), last={k:v for k,v in last.items() if k != 'measurement'},
            last_execution=last['measurement']['execution_seconds'] if last.get('measurement') else None)))
    if (root / name / 'summary.json').exists():
        summary = json.loads((root / name / 'summary.json').read_text())
        print(json.dumps(dict(campaign=name, result=summary.get('timing_gate', summary.get('metrics')))))
