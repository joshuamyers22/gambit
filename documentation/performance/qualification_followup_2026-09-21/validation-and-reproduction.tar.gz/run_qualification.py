"""Fixed 4x50 campaign; contemporaneous conditions, no selective replacement."""
import json
import os
from pathlib import Path
import sys
import time
from datetime import datetime, timezone

root = Path(__file__).parent
candidate_record = json.loads((root / 'qualification-candidate.json').read_text())
release = json.loads((root / 'release-fixed-complete.json').read_text())
assert release['status'] == 'completed' and release['conclusion'] == 'success'
assert release['headSha'] == candidate_record['candidate_commit']
candidate = Path(candidate_record['candidate'])
os.environ['PYTHONPATH'] = str(candidate / 'src')
sys.path[:0] = [str(candidate / 'src'), str(candidate / 'benchmarks')]
import psutil
from controlled_replay import identity, reference_matches, build_attested, run_trial, observe_conditions, session_evidence
from replay_contract import workload, write_json, summarize

def utc():
    return datetime.now(timezone.utc).isoformat()

def environmental_failure(conditions):
    if 'AC Power' not in (conditions.get('power') or ''):
        return 'AC power not observed'
    settings = conditions.get('power_settings') or ''
    if not any(line.split() == ['lowpowermode', '0'] for line in settings.splitlines()):
        return 'low-power mode off not observed'
    thermal = conditions.get('thermal') or ''
    if 'No thermal warning level has been recorded' not in thermal:
        return 'thermal state changed or unavailable'
    if 'No performance warning level has been recorded' not in thermal:
        return 'performance warning state changed or unavailable'
    return None

def processes():
    rows = {}
    for p in psutil.process_iter(['pid', 'name', 'cpu_times']):
        try:
            cpu = p.info['cpu_times']
            rows[str(p.pid)] = dict(name=p.info['name'], cpu_seconds=cpu.user + cpu.system)
        except (psutil.Error, AttributeError):
            pass
    return rows

probe = json.loads((root / 'full-volume-overhead/summary.json').read_text())
assert probe['full_volume'] and probe['pairs'] == 30
assert probe['metrics']['execution_seconds']['conclusion'] == 'within_1_percent', probe['metrics']
build = json.loads((root.parent / 'lat09-2026-09-20/retained-native-build.json').read_text())
observed = identity()
assert reference_matches(observed) and build_attested(build, observed)
assert observed['revision'] == candidate_record['candidate_commit']
assert observed['dirty_state'] == ''
probe_identity = json.loads((root / 'full-volume-overhead/experiment.json').read_text())['identity']
assert {k:v for k,v in observed.items() if k != 'revision'} == {
    k:v for k,v in probe_identity.items() if k != 'revision'
}, 'Measurement source/build differs from the full-volume overhead comparison'
output = root / 'qualification'
output.mkdir(exist_ok=False)
write_json(output / 'plan.json', dict(started_at=utc(), identity=observed, sessions=4, trials_per_session=50,
    quiet_seconds=300, operator='Codex, under Joshua Myers authorization in workspace session',
    user_conditions='Joshua Myers reserved this Mac on AC power with low-power mode off and other workloads paused.',
    invalidation=['power transition', 'thermal/performance warning or unavailable observation',
                  'sleep or scheduling gap over 90 seconds during quiet interval', 'source/build identity change',
                  'operator reports competing scheduled workload'],
    policy='All observations retained. Stop on environment failure; never discard or rerun slow trials.',
    independence='Four sequential sessions with fresh quiet intervals; correlation and reviewer assessment remain required.'))
trials = []
spec = workload('fifo-3y-sparse-v1')
for session in range(1, 5):
    directory = output / f'session-{session}'
    directory.mkdir()
    quiet_start = utc()
    previous = processes()
    quiet = []
    last = time.monotonic()
    for minute in range(5):
        time.sleep(60)
        now = time.monotonic()
        conditions = observe_conditions()
        current = processes()
        activity = sorted([dict(pid=pid, name=row['name'], cpu_seconds=max(0., row['cpu_seconds'] -
            previous.get(pid, dict(cpu_seconds=0.))['cpu_seconds'])) for pid, row in current.items()],
            key=lambda row: row['cpu_seconds'], reverse=True)[:15]
        quiet.append(dict(observed_at=utc(), elapsed_seconds=now-last, conditions=conditions, top_cpu_deltas=activity))
        write_json(directory / f'quiet-{minute+1}.json', quiet[-1])
        failure = environmental_failure(conditions) or ('quiet scheduling gap' if now-last > 90 else None)
        if failure:
            write_json(output / 'environment-failure.json', dict(session=session, reason=failure, time=utc()))
            raise SystemExit(1)
        previous, last = current, time.monotonic()
        print(json.dumps(dict(session=session, quiet_minutes=minute+1)), flush=True)
    evidence_path = directory / 'session-evidence.json'
    write_json(evidence_path, dict(operator='Codex under Joshua Myers campaign authorization',
        quiet_period_start_utc=quiet_start, quiet_period_end_utc=utc(), ac_power=True, low_power_mode=False,
        background_workloads='User reserved host and paused other workloads. See five contemporaneous quiet CPU samples; macOS services remain active.',
        power_thermal_notes='Observed AC and low-power mode off; no recorded thermal/performance warnings. caffeinate -i prevents idle system sleep.',
        independence_notes='Sequential session after separate five-minute quiet interval; fresh workers. Statistical independence awaits correlation review.',
        reviewer='Joshua Myers', review_status='pending'))
    evidence = session_evidence(evidence_path)
    for index in range(1, 51):
        trial = run_trial(directory / f'trial-{index:03d}', spec, session_id=f'qualification-{session}',
                          evidence=evidence, build_manifest=build)
        trials.append(trial)
        print(json.dumps(dict(session=session, trial=index, status=trial['status'], measurement=trial['measurement'])), flush=True)
        failure = (environmental_failure(trial['conditions_before']) or environmental_failure(trial['conditions_after']))
        if trial['identity'] != observed:
            failure = 'source/build/host identity changed'
        if failure or trial['status'] != 'ok':
            write_json(output / 'failure.json', dict(session=session, trial=index, reason=failure or trial['failure_reason']))
            write_json(output / 'partial-summary.json', summarize(trials))
            raise SystemExit(1)
    write_json(directory / 'summary.json', summarize(trials[-50:]))
write_json(output / 'summary.json', summarize(trials))
print(json.dumps(summarize(trials)), flush=True)
