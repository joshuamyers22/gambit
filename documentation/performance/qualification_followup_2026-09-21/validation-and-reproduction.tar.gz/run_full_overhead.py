"""Predeclared thirty-pair full-volume probe comparison on frozen candidate."""
import json
import os
from pathlib import Path
import sys

root = Path(__file__).parent
candidate = Path('/Users/jkm0607/Projects/gambit-lat09-qualification')
os.environ['PYTHONPATH'] = str(candidate / 'src')
sys.path[:0] = [str(candidate / 'src'), str(candidate / 'benchmarks')]
from controlled_replay import identity, reference_matches, build_attested, run_trial, observe_conditions
from profile_replay import overhead_summary, clock_calibration
from replay_contract import workload, write_json

build = json.loads((root.parent / 'lat09-2026-09-20/retained-native-build.json').read_text())
observed = identity()
assert reference_matches(observed), observed
assert observed['revision'] == '9892c75e41c98a2648e1790d200fa3301a42c606'
assert observed['dirty_state'] == ''
assert build_attested(build, observed)
output = root / 'full-volume-overhead'
output.mkdir(exist_ok=False)
spec = workload('fifo-3y-sparse-v1')
write_json(output / 'experiment.json', dict(planned_pairs=30, workload=spec, identity=observed,
    conditions_before=observe_conditions(), clock_calibration=clock_calibration(),
    interpretation='diagnostic only; no selective extension or removal of pairs'))
trials = []
for pair in range(30):
    for mode in (('timers_only', 'full') if pair % 2 == 0 else ('full', 'timers_only')):
        trial = run_trial(output / f'{pair+1:03d}-{mode}', spec,
            session_id='lat09-full-volume-overhead', build_manifest=build,
            diagnostic=dict(instrumentation=mode, prefix_ticks=spec['ticks']))
        trials.append(trial)
        print(json.dumps(dict(pair=pair+1, mode=mode, status=trial['status'],
                              measurement=trial['measurement'])), flush=True)
        if trial['status'] != 'ok':
            write_json(output / 'failure.json', trial)
            raise SystemExit(1)
summary = overhead_summary(trials)
summary.update(full_volume=True, measured_ticks_per_trial=spec['ticks'],
               conditions_after=observe_conditions())
write_json(output / 'summary.json', summary)
print(json.dumps(summary), flush=True)
