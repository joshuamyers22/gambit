import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).parent
source = Path('/Users/jkm0607/Projects/gambit')
candidate = Path('/Users/jkm0607/Projects/gambit-lat09-release-fixes')
expected = '126451bfc3c16b2a2bca2ce810fbdd9f3accad6d'
def git(*args):
    return subprocess.check_output(['git', *args], cwd=candidate).decode().strip()
assert git('rev-parse', 'HEAD') == expected
assert git('diff', '--name-only', '9892c75', expected) == 'tests/test_replay_profiling.py'
assert git('status', '--porcelain') == ''
artifacts = []
for path in (source / 'src').rglob('*.cpython-310-darwin.so'):
    target = candidate / path.relative_to(source)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)
    artifacts.append(dict(path=str(target.relative_to(candidate)), sha256=hashlib.sha256(target.read_bytes()).hexdigest()))
assert any(row['sha256'] == '9bb6074a0149a302edd4a1f8ab3063f3ae830b15418342738dcacfde450ffb39' for row in artifacts)
assert git('status', '--porcelain') == ''
record = dict(candidate=str(candidate), candidate_commit=expected, candidate_tree=git('rev-parse','HEAD^{tree}'),
    runtime_changes_since_probe_candidate=[], test_changes=['tests/test_replay_profiling.py'], artifacts=artifacts,
    release_validation='https://github.com/joshuamyers22/gambit/actions/runs/35605565645',
    reviewer='Joshua Myers', review_status='pending')
with (root / 'qualification-candidate.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record, indent=2))
