"""Package retained measurements and CI results without changing raw evidence."""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

root = Path(__file__).parent
repo = Path('/Users/jkm0607/Projects/gambit-lat09-promotion-evidence')
bundle = repo / 'documentation/performance/qualification_followup_2026-09-21'
bundle.mkdir(parents=True, exist_ok=True)
def read(path):
    return json.loads(path.read_text())
def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')
def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            result.update(chunk)
    return result.hexdigest()
def archive(target, files, base):
    with tarfile.open(target, 'w:gz') as output:
        for path in sorted(files):
            output.add(path, arcname=str(path.relative_to(base)), recursive=False)

release = read(root / 'release-fixed-complete.json')
candidate = read(root / 'qualification-candidate.json')
assert release['headSha'] == candidate['candidate_commit']
assert release['status'] == 'completed' and release['conclusion'] == 'success'
assert len(release['jobs']) == 28
assert sum(j['conclusion'] == 'success' for j in release['jobs']) == 26
assert all(j['conclusion'] in ('success','skipped') for j in release['jobs'])
assert {j['name'] for j in release['jobs'] if j['conclusion'] == 'skipped'} == {'publish-pypi','publish-testpypi'}
trials = [read(path) for path in sorted((root / 'full-volume-overhead').glob('*/trial.json'))]
assert len(trials) == 60
assert all(t['status'] == 'ok' and t['reference_host_matches'] and t['build_attested'] for t in trials)
assert all(t['workload']['ticks'] == t['diagnostic']['prefix_ticks'] == 946944000 for t in trials)
assert len({json.dumps(t['identity'],sort_keys=True) for t in trials}) == 1
assert len({json.dumps(t['measurement']['controls'],sort_keys=True) for t in trials}) == 1
assert all(t['identity']['revision'] == '9892c75e41c98a2648e1790d200fa3301a42c606' for t in trials)
assert all(t['identity']['dirty_state'] == '' for t in trials)
assert all(t['measurement']['controls'] == dict(
    input_sha256='8e03b1e7d62ff6683a055718ef7818cf5188a56bf48084a1df1fb7095369465f',
    result_sha256='5e663f1117533205af50d1297faae98a791b720dff2215386fecb09272c8b2d6',
    order_count=88776,fill_count=595838) for t in trials)
assert all(read(p)['measured_ticks'] == 946944000
           for p in (root / 'full-volume-overhead').glob('*/worker-result.json'))
summary = read(root / 'full-volume-overhead/summary.json')
assert summary['pairs'] == 30 and summary['full_volume']
assert summary['metrics']['execution_seconds']['conclusion'] == 'inconclusive_at_1_percent'
assert not (root / 'qualification').exists()
assert '2283 passed' in (root / 'make-check.log').read_text()
assert '15 passed' in (root / 'focused-tests.log').read_text()
assert '3 passed' in (root / 'document-contract-tests.log').read_text()
assert 'build succeeded.' in (root / 'docs.log').read_text()
assert 'verified 9 wheel(s)' in (root / 'release-artifact-validation.log').read_text()
artifacts = [dict(name=p.name,size_bytes=p.stat().st_size,sha256=digest(p))
             for p in sorted((root / 'release-artifacts').iterdir()) if p.is_file()]
assert len(artifacts) == 10
write(root / 'release-artifacts.json',dict(run=release['url'],candidate_commit=release['headSha'],artifacts=artifacts,
    local_directory=str(root / 'release-artifacts'),published=False))
decision = dict(disposition='remain_experimental',promotion_approved=False,
    candidate_commit=candidate['candidate_commit'], measured_commit=trials[0]['identity']['revision'],
    source_transfer='Only profiling test isolation differs; benchmark and native sources/binary unchanged.',
    reviewer='Joshua Myers',independent_review='pending',production_data_validation='deferred_per_user',
    qualification_campaign=dict(status='not_started',trials=0,reason='Full-volume execution probe target remains inconclusive.'),
    gates=dict(committed_candidate='complete',independent_candidate_review='pending',
        supported_platform_release_validation='passed',full_volume_probe_experiment='complete',
        execution_probe_target='inconclusive_at_1_percent',primary_200_trial_qualification='not_started',
        representative_production_parity_calibration_storage='deferred_per_user',promotion='not_approved'),
    probe=dict(pairs=30,trials=60,records=sum(t['workload']['ticks'] for t in trials),
        execution=summary['metrics']['execution_seconds'],harness=summary['metrics']['harness_seconds'],
        maximum_rss_bytes=max(t['measurement']['peak_rss_bytes'] for t in trials),
        all_controls_match=True,all_successful=True,performance_qualification=False),
    validation=dict(local_make_check_tests=2283,focused_tests=15,document_contract_tests=3,docs='passed',release_jobs_passed=26,
                    publication_jobs_skipped=2,wheels=9,sdists=1))
write(root / 'decision.json',decision)
for name in ('candidate.json','qualification-candidate.json','decision.json','release-fixed-complete.json',
             'release-artifacts.json','production-corpus-assessment.json'):
    shutil.copy2(root / name,bundle / name)
shutil.copy2(root / 'full-volume-overhead/summary.json',bundle / 'probe-summary.json')
shutil.copy2(root / 'full-volume-overhead/experiment.json',bundle / 'probe-experiment.json')
archive(bundle / 'full-volume-probe-trials.tar.gz',
        [p for p in (root / 'full-volume-overhead').rglob('*') if p.is_file()],root / 'full-volume-overhead')
logs = [root/name for name in ('linux311.log','linux312.log','diagnostic-linux312.log','release-fixed.log',
                             'release-initial.json','diagnostic-ci-progress.json')]
archive(bundle / 'release-ci-logs.tar.gz',logs,root)
reproduction = [p for p in root.iterdir() if p.suffix in ('.py','.patch','.nul')]
reproduction += [root/name for name in ('make-check.log','focused-tests.log','document-contract-tests.log','docs.log','release-artifact-validation.log',
                                       'full-volume-overhead.log','review-notes.md')]
reproduction += [p for p in (root / 'focused-tests').rglob('*') if p.is_file()]
archive(bundle / 'validation-and-reproduction.tar.gz',reproduction,root)
external = sorted(set(logs+reproduction+[p for p in (root / 'release-artifacts').iterdir() if p.is_file()]))
write(bundle / 'external-evidence-manifest.json',dict(root=str(root),files=[dict(
    path=str(p.relative_to(root)),size_bytes=p.stat().st_size,sha256=digest(p)) for p in external]))
(bundle / 'README.md').write_text('''# LAT-09 promotion follow-up evidence

The [report](../qualification_followup_2026-09-21.md) records **remain experimental**.
Release validation passed; the full-volume ≤1% execution probe target remains
inconclusive. No 200-trial qualification campaign was run. Production-data
validation is deferred and Joshua Myers's independent review is pending.

`full-volume-probe-trials.tar.gz` contains all 60 successful diagnostic trials,
their requests/results, build identities and retained controls. No slow sample was
removed. `probe-summary.json` contains all 30 paired effects and the unchanged
deterministic bootstrap result. These diagnostic trials cannot become qualification.

The release records identify candidate `126451b` and the passing GitHub run.
Wheel/sdist binaries remain outside Git, with SHA-256 digests and download/run
locations in `release-artifacts.json`. The CI archive retains both initial Linux
failure logs and the successful release log. The reproduction archive contains
the test correction, commands, local validation, and unexecuted qualification
orchestration. An unexecuted script is not evidence of completed sessions.

The external manifest covers the specifically enumerated retained files; it does
not claim to inventory every disposable environment or prior experiment. No
licensed market-data file is included. `manifest.json` hashes this compact bundle.
''')
write(bundle / 'manifest.json',dict(schema='gambit-lat09-followup-evidence-v1',files=[dict(
    path=p.name,size_bytes=p.stat().st_size,sha256=digest(p))
    for p in sorted(bundle.iterdir()) if p.is_file() and p.name!='manifest.json']))
for row in read(bundle / 'manifest.json')['files']:
    assert digest(bundle / row['path']) == row['sha256']
print(json.dumps(dict(bundle=str(bundle),bytes=sum(p.stat().st_size for p in bundle.iterdir()),
    maximum_rss_mib=decision['probe']['maximum_rss_bytes']/1024**2,records=decision['probe']['records']),indent=2))
