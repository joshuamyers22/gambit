"""Freeze the authorized LAT changes without modifying the user's branch/index."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

repo = Path('/Users/jkm0607/Projects/gambit')
out = Path(__file__).parent
candidate = Path('/Users/jkm0607/Projects/gambit-lat09-qualification')
env = dict(os.environ, GIT_INDEX_FILE=str(out / 'candidate.index'))
def git(*args, **kwargs):
    return subprocess.check_output(['git', *args], cwd=repo, env=env, **kwargs)

base = git('rev-parse', 'HEAD').decode().strip()
paths = subprocess.check_output(['git', 'ls-files', '--modified', '--others', '--exclude-standard', '-z'],
                                cwd=repo).decode().split('\0')
paths = sorted(p for p in paths if p and p != 'GAMBIT_MCP_PROJECT_PLAN.md')
git('read-tree', base)
git('add', '--', *paths)
tree = git('write-tree').decode().strip()
message = b'Prepare LAT-01 through LAT-09 experimental latency qualification candidate\n'
if candidate.exists():
    commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=candidate).decode().strip()
    assert git('rev-parse', commit + '^{tree}').decode().strip() == tree
else:
    commit = git('commit-tree', tree, '-p', base, input=message).decode().strip()
    subprocess.check_call(['git', 'worktree', 'add', '-b', 'lat09-qualification', str(candidate), commit], cwd=repo)
for source in (repo / 'src').rglob('*.so'):
    target = candidate / source.relative_to(repo)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
native = candidate / 'src/gambit/_factor_cache.cpython-310-darwin.so'
sha = hashlib.sha256(native.read_bytes()).hexdigest()
assert sha == '9bb6074a0149a302edd4a1f8ab3063f3ae830b15418342738dcacfde450ffb39'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=candidate)
record = dict(base=base, candidate_commit=commit, candidate_tree=tree, candidate=str(candidate),
              included_paths=paths, native_sha256=sha,
              reviewer='Joshua Myers', review_status='pending', promotion_status='not_approved')
(out / 'candidate.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
