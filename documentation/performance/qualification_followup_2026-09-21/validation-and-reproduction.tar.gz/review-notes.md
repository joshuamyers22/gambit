# LAT-09 promotion follow-up, 2026-09-21

Promotion is not approved. Joshua Myers is the named independent human reviewer;
the user delegated strategy/corpus selection and reserved the reference Mac for
the performance campaign. Naming a reviewer is not a completed review or approval.

## Candidate and retained implementation

The clean initial candidate is `9892c75e41c98a2648e1790d200fa3301a42c606`,
on `lat09-qualification`. The source workspace and its index were preserved;
the unrelated `GAMBIT_MCP_PROJECT_PLAN.md` was excluded. The candidate contains the
previous LAT-01 through LAT-09 work, including the original concurrent ring,
legacy input default, and optional fused generator and detailed diagnostics.

The release candidate after diagnostic-test corrections is `126451b` on
`lat09-release-fixes`. Only `tests/test_replay_profiling.py` differs from the
initial candidate. The FIFO native binary and runner sources are unchanged.
The retained CPython 3.10 native binary is
`9bb6074a0149a302edd4a1f8ab3063f3ae830b15418342738dcacfde450ffb39`.
Both candidate branches were pushed; no release, package publication or deployment
was requested by these workflows (`publish_testpypi=false`).

## Release validation findings

Fresh local `make check` passed 2,283 tests, with lint, typing, coverage/mutation
policy, native warnings, docs and distribution checks. The native source and
extension remain those of the prior full-trace comparison.

The initial release run exposed two supervised diagnostic tests failing on Linux
Python 3.11/3.12 because the worker reported a 512 MiB high-water breach when
launched by the accumulated coverage process. The tests now launch the unchanged
runner through a small independent controller, matching standalone CLI usage.
The replay's 512 MiB bound is unchanged; there is no skip, raised limit or
subtraction. Failure assertions now retain the worker reason and stderr; each
successful diagnostic also writes controller current/high-water memory evidence.

Linux documents that resource-usage metrics survive exec:
[getrusage(2)](https://www.man7.org/linux/man-pages/man2/getrusage.2.html).
That explains why a large forking test process can contaminate a fresh exec's
high-water measurement. The second fork from a small controller gives the replay
its intended process footprint while retaining warmup/import peaks.

Initial failed run: https://github.com/joshuamyers22/gambit/actions/runs/35604445710

Diagnostic run: https://github.com/joshuamyers22/gambit/actions/runs/35605011148

Fixed release run: https://github.com/joshuamyers22/gambit/actions/runs/35605565645

## Production corpus decision

Select the native supported single-owner passive FIFO long/flat policy for this
promotion scope. It requires event-level quotes, displayed sizes, individual
trades with aggressor direction, stable ordering and documented timestamp
semantics. General Python Strategy parity is not implied.

The inspected local SPX options archive is documented as five-minute snapshots,
with bid/ask, sizes and volume but no individual ordered trade/aggressor stream.
The concrete August 3, 2026 file is recorded in `production-corpus-assessment.json`.
It is rejected for FIFO semantic qualification. A storage/decode measurement on
that format would not establish queue depletion, production execution calibration
or valid receive-time assumptions. No trades or timestamps may be manufactured
to fill these gaps. A suitable production corpus has not been identified.
The user deferred this production-data requirement for now; it remains an open
promotion gate, rather than an approved substitution of snapshots or synthetic data.

## Remaining evidence

The predeclared 30-pair full-volume instrumentation comparison and fixed four
sessions of 50 qualification observations must be reviewed before filling in
their gate status. All failures and slow observations remain part of the record.
Temporal independence requires assessment, not only distinct session IDs.

Joshua Myers must review the final immutable candidate and complete evidence,
including unmet production-corpus/calibration/storage requirements, before any
affirmative promotion decision can be recorded.
