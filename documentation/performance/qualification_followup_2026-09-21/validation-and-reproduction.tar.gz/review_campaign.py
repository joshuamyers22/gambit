"""Descriptive session/correlation evidence; never substitute for human review."""
import json
from pathlib import Path
import sys

import numpy as np

root = Path(__file__).parent
candidate = Path(json.loads((root / 'qualification-candidate.json').read_text())['candidate'])
sys.path.insert(0, str(candidate / 'benchmarks'))
from replay_contract import distribution, summarize, write_json

groups = []
for session in range(1, 5):
    paths = sorted((root / f'qualification/session-{session}').glob('trial-*/trial.json'))
    assert len(paths) == 50, (session, len(paths))
    groups.append([json.loads(path.read_text()) for path in paths])
trials = [row for group in groups for row in group]
summary = summarize(trials)
assert summary['trials'] == 200
assert all(row['status'] == 'ok' for row in trials)
metrics = {}
for name in ('execution_seconds', 'harness_seconds', 'peak_rss_bytes'):
    sessions = [np.array([row['measurement'][name] for row in group]) for group in groups]
    correlations = {}
    for lag in range(1, 11):
        # Center each session separately; do not invent cross-session adjacency.
        left = np.concatenate([(s-s.mean())[:-lag] for s in sessions])
        right = np.concatenate([(s-s.mean())[lag:] for s in sessions])
        correlations[str(lag)] = (float(np.corrcoef(left,right)[0,1])
                                  if left.std() > 0 and right.std() > 0 else None)
    metrics[name] = dict(sessions=[distribution(s.tolist()) for s in sessions],
                         within_session_lag_correlations=correlations,
                         session_means=[float(s.mean()) for s in sessions],
                         session_slopes_per_trial=[float(np.polyfit(np.arange(50),s,1)[0]) for s in sessions])
record = dict(candidate_commit=trials[0]['identity']['revision'], timing_gate=summary['timing_gate'],
    metrics=metrics, independent_review='pending Joshua Myers review',
    interpretation='Descriptive dependence checks. Small sample correlations or fresh processes do not prove independence; the binomial gate remains conditional on credible trial independence.')
write_json(root / 'qualification/correlation-review.json',record)
print(json.dumps(record,indent=2))
