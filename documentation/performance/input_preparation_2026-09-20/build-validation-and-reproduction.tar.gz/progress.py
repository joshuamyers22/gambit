import json
from pathlib import Path
root = Path(__file__).parent
for name in ['primary','dense-1m','dense-2m','chunk-65536-prefix','chunk-1048576-prefix',
             'storage-1m-uncontrolled','storage-1m-warm','storage-2m-uncontrolled','storage-2m-warm']:
    paths = sorted((root / name).glob('*/trial.json'))
    if not paths: continue
    rows = [json.loads(p.read_text()) for p in paths]
    latest = max(zip(paths, rows), key=lambda item: item[0].stat().st_mtime)[1]
    metric = latest.get('measurement') or {}
    print(name, 'complete' if (root/name/'summary.json').exists() else 'running',
          'workers',len(rows),'failures',sum(r['status']!='ok' for r in rows),
          'latest',latest['input_mode'],round(metric.get('harness_seconds',0),3))
