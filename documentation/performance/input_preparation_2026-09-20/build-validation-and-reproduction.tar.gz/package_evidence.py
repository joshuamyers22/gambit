import hashlib
import json
import shutil
import tarfile
from pathlib import Path

repo = Path('/Users/jkm0607/Projects/gambit')
root = repo.parent / 'gambit-evidence/lat07-2026-09-20'
out = repo / 'documentation/performance/input_preparation_2026-09-20'

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def archive(path, items):
    with tarfile.open(path, 'w:gz') as tar:
        for source, name in items:
            tar.add(source, arcname=name, recursive=False)

campaigns = sorted(p for p in root.iterdir() if p.is_dir() and (p / 'campaign.json').exists())
assert len(campaigns) == 11
trials = [json.loads(p.read_text()) for c in campaigns for p in sorted(c.glob('*/trial.json'))]
assert len(trials) == 606
assert len({t['trial_id'] for t in trials}) == 606
assert sum(json.loads(p.read_text())['measured_ticks'] for c in campaigns for p in c.glob('*/worker-result.json')) == 65075640000
native_sha = '9bb6074a0149a302edd4a1f8ab3063f3ae830b15418342738dcacfde450ffb39'
assert all(t['status'] == 'ok' and t['identity']['native_extension_sha256'] == native_sha for t in trials)
assert digest(root / 'baseline-factor.so') == native_sha
native = list((repo / 'src/gambit').glob('_factor_cache*.so'))
if not native:
    native = list(repo.glob('**/_factor_cache*.so'))
assert native and any(digest(p) == native_sha for p in native)
source_identities = {'runner_sha256': 'benchmarks/controlled_replay.py', 'contract_code_sha256': 'benchmarks/replay_contract.py', 'input_reader_sha256': 'benchmarks/replay_input.py', 'generator_sha256': 'benchmarks/top_of_book_backtest.py'}
for key, filename in source_identities.items():
    assert all(t['identity'][key] == digest(repo / filename) for t in trials), key
for c in campaigns:
    rows = [json.loads(p.read_text()) for p in sorted(c.glob('*/trial.json'))]
    assert len({json.dumps(t['measurement']['controls'], sort_keys=True) for t in rows}) == 1, c.name
    shutil.copyfile(c / 'summary.json', out / (c.name + '-summary.json'))
archive(out / 'measured-trials.tar.gz', [(p, str(p.relative_to(root))) for c in campaigns for p in sorted(c.rglob('*')) if p.is_file()])
archive(out / 'preliminary-trials.tar.gz', [(p, str(p.relative_to(root))) for c in sorted(root.glob('preliminary-*')) for p in sorted(c.rglob('*')) if p.is_file()])
record_files = [p for p in sorted(root.iterdir()) if p.is_file() and p.suffix in ('.log', '.py', '.txt')]
record_files += [p for name in ('fused-build', 'fused-sanitized', 'corpus-1m', 'corpus-2m') for p in sorted((root / name).rglob('*')) if p.is_file() and p.suffix in ('.json', '.log')]
archive(out / 'build-validation-and-reproduction.tar.gz', [(p, str(p.relative_to(root))) for p in record_files])
source_files = list(source_identities.values()) + ['benchmarks/fused_queue_input.cpp', 'benchmarks/input_comparison.py', 'tests/test_replay_input.py', 'tests/test_input_comparison.py', 'Makefile', 'tools/check_native_warnings.py', 'LATENCY_INFRASTRUCTURE_PROJECT_PLAN.md', 'PRODUCTION_READINESS_PLAN.md', 'documentation/operations/replay_input.md', 'documentation/performance/input_preparation_2026-09-20.md']
archive(out / 'source-snapshot.tar.gz', [(repo / name, name) for name in source_files])
primary = json.loads((root / 'primary/summary.json').read_text())['fused']
write(out / 'decision.json', {
    'task': 'LAT-07', 'status': 'complete for synthetic engineering acceptance',
    'decision': 'retain fused synthetic generator as explicit experimental option; legacy remains default; storage alternatives are comparison tools only',
    'original_ring_retained': True, 'native_extension_sha256': native_sha,
    'performance_qualification': False, 'cold_storage_measured': False,
    'real_data_decode_measured': False, 'measured_campaigns': 11,
    'distinct_successful_workers': 606, 'measured_records': 65075640000,
    'preliminary_workers_excluded': 6, 'primary': primary,
    'short_chunk_tail': 'Original 10m-prefix p95 execution +7.55%; fresh replication -5.43%; longer 100m control +2.68%. Retain all observations separately; no physical cause established.',
    'validation': {'make_check_tests': 2247, 'asan_ubsan_tests': 28, 'asan_quarantine_mib': 16, 'leak_detection': False, 'make_check_passed': True},
    'next': 'LAT-08 batch-level metrics, queue high-water/full/age signals, failure summaries and bounded shutdown reporting'
})
external_files = [p for p in sorted(root.rglob('*')) if p.is_file()]
write(out / 'external-evidence-manifest.json', {'root': str(root), 'files': {str(p.relative_to(root)): {'sha256': digest(p), 'bytes': p.stat().st_size} for p in external_files}})
(out / 'README.md').write_text('''# LAT-07 evidence bundle\n\nSee the [report](../input_preparation_2026-09-20.md) and [runbook](../../operations/replay_input.md).\n\n- `measured-trials.tar.gz`: all 606 workers, requests, raw results, stderr and 11 campaign records.\n- `*-summary.json`: individual campaign statistics; workloads remain separate.\n- `preliminary-trials.tar.gz`: six excluded preliminary workers.\n- `build-validation-and-reproduction.tar.gz`: compiler records, corpus manifests, orchestration scripts and validation logs, including unsuccessful early checks and their successful repeats. Top-level replay Python files here are pre-LAT-07 baseline snapshots.\n- `source-snapshot.tar.gz`: final measured benchmark implementation, tests, runbook and plans.\n- `decision.json`: experimental retention decision and scope.\n- `external-evidence-manifest.json`: hashes of full external evidence, including corpus bytes and native libraries omitted from this bundle.\n- `manifest.json`: hashes for this bundle and repository source files.\n\nAll measured workers succeeded with identical per-workload input/result controls and the unchanged FIFO binary. Source identities were checked against the measured trials when packaging. Baseline and candidate share the same runner; only the selected input mode changes. No cold-cache, real-data decode or production qualification is claimed.\n''')
write(out / 'manifest.json', {'schema': 'gambit-lat07-evidence-v1', 'artifacts': {p.name: {'sha256': digest(p), 'bytes': p.stat().st_size} for p in sorted(out.iterdir()) if p.name != 'manifest.json'}, 'repository_sources': {name: digest(repo / name) for name in source_files}})
manifest = json.loads((out / 'manifest.json').read_text())
assert all(digest(out / name) == item['sha256'] for name, item in manifest['artifacts'].items())
with tarfile.open(out / 'measured-trials.tar.gz') as tar:
    assert sum(m.name.endswith('/trial.json') for m in tar.getmembers()) == 606
print(json.dumps({'campaigns': len(campaigns), 'workers': len(trials), 'measured_records': sum(json.loads(p.read_text())['measured_ticks'] for c in campaigns for p in c.glob('*/worker-result.json')), 'bundle_bytes': sum(p.stat().st_size for p in out.iterdir()), 'native_unchanged': True, 'source_and_bundle_hashes_verified': True}, indent=2))
