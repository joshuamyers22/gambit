from pathlib import Path
import json
import sys
from datetime import datetime, timezone

ROOT = Path('/Users/jkm0607/Projects/gambit')
sys.path.insert(0, str(ROOT / 'benchmarks'))
from input_comparison import campaign
from replay_contract import workload

EVIDENCE = ROOT.parent / 'gambit-evidence/lat07-2026-09-20'
LIBRARY = EVIDENCE / 'fused-build/queue_input.dylib'
plans = [
    ('primary', 'fifo-3y-sparse-v1', 65521, None),
    ('dense-1m', 'fifo-1m-dense-v1', 65521, None),
    ('dense-2m', 'fifo-2m-dense-v1', 65521, None),
    ('chunk-65536-prefix', 'fifo-3y-sparse-v1', 65536, 10000000),
    ('chunk-1048576-prefix', 'fifo-3y-sparse-v1', 1048576, 10000000),
]
for name, scenario, chunk, prefix in plans:
    print(json.dumps(dict(start=name, at=datetime.now(timezone.utc).isoformat())), flush=True)
    result = campaign(EVIDENCE / name, workload(scenario, chunk), ['legacy', 'fused'],
                      library=LIBRARY, pairs=30, prefix=prefix)
    print(json.dumps(dict(complete=name, summary=result)), flush=True)
for count in ['1m', '2m']:
    for warm in [False, True]:
        name = 'storage-' + count + ('-warm' if warm else '-uncontrolled')
        print(json.dumps(dict(start=name, at=datetime.now(timezone.utc).isoformat())), flush=True)
        result = campaign(EVIDENCE / name, workload('fifo-' + count + '-dense-v1'),
                          ['legacy', 'readinto', 'mmap'], dataset=EVIDENCE / ('corpus-' + count),
                          pairs=30 if warm else 1, warm_cache=warm)
        print(json.dumps(dict(complete=name, summary=result)), flush=True)
