"""Reproduce setup.py's factor-only commands, retaining exact build provenance."""
import argparse
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import shutil
p=argparse.ArgumentParser()
p.add_argument('--output',type=Path,required=True)
p.add_argument('--source',type=Path,default=Path('/Users/jkm0607/Projects/gambit'))
p.add_argument('--sanitize',action='store_true')
a=p.parse_args(); a.output.mkdir(parents=True,exist_ok=False)
log=Path(__file__).with_name('variant1-build-installed.log').read_text()
commands=[shlex.split(line) for line in log.splitlines() if line.startswith('c++ ') and ('factor_cache/' in line or '_factor_cache.cpython-310' in line)]
outputs={}
compile_commands=[]; link_commands=[]
with (a.output/'compiler.log').open('w') as stream:
    for original in commands:
        old_output=original[original.index('-o')+1]
        new_output=str(a.output/Path(old_output).name)
        outputs[old_output]=new_output
        command=[outputs.get(arg,arg) for arg in original]
        if a.sanitize:
            command=['-O1' if arg=='-O3' else arg for arg in command]
            command+=['-fsanitize=address,undefined','-fno-omit-frame-pointer']
        (compile_commands if '-c' in command else link_commands).append(command)
        print(shlex.join(command),file=stream,flush=True)
        subprocess.run(command,cwd=a.source,stdout=stream,stderr=subprocess.STDOUT,check=True)
extension=a.output/'_factor_cache.cpython-310-darwin.so'
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=dict(compiler_version=subprocess.check_output(['c++','--version'],text=True),compile_commands=compile_commands,link_commands=link_commands,cwd=str(a.source),native_extension_sha256=hashfile(extension),source_sha256=hashfile(a.source/'src/gambit/cpp/factor_cache/top_of_book_backtest.cpp'),all_sources={str(p.relative_to(a.source)):hashfile(p) for p in (a.source/'src/gambit/cpp/factor_cache').glob('*') if p.is_file()},sanitized=a.sanitize)
(a.output/'build.json').write_text(json.dumps(manifest,indent=2)+'\n')
shutil.copy2(a.source/'src/gambit/cpp/factor_cache/top_of_book_backtest.cpp',a.output/'top_of_book_backtest.cpp')
print(json.dumps(manifest),flush=True)
