"""Run only after screening finishes; preserve compact reports and immutable raw identities."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile
E=Path(__file__).resolve().parent
R=Path('/Users/jkm0607/Projects/gambit/documentation/performance/fifo_optimization_2026-09-20')
R.mkdir(exist_ok=False)
campaigns=['3y-sparse','1m-dense','2m-dense','chunk-65536-prefix','chunk-1048576-prefix']
read=lambda p: json.loads(p.read_text())
write=lambda p,v:p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
comparisons={}
for name in campaigns:
    summary=read(E/name/'summary.json')
    comparison=summary.get('paired_comparison',summary)
    if comparison['status'] not in ('retention_signal','no_retention_signal'): raise RuntimeError((name,comparison))
    trials=[read(p) for p in sorted((E/name).glob('*/trial.json'))]
    if len(trials)!=60 or any(t['status']!='ok' for t in trials): raise RuntimeError(name)
    comparison['maximum_rss_ratio']=max(t['measurement']['peak_rss_bytes'] for t in trials if t['variant']=='candidate')/max(t['measurement']['peak_rss_bytes'] for t in trials if t['variant']=='baseline')
    comparison['all_trials_same_controls']=len({json.dumps(t['measurement']['controls'],sort_keys=True) for t in trials})==1
    comparison['all_reference_host_matches']=all(t['reference_host_matches'] for t in trials)
    comparison['candidate_build_attested']=all(t['build_attested'] for t in trials if t['variant']=='candidate')
    comparisons[name]=comparison
    shutil.copy2(E/name/'summary.json',R/(name+'-summary.json'))
for name in [*campaigns,'variant1-prefix','parity','memory-followup']:
    with tarfile.open(R/(name+'-raw.tar.gz'),'w:gz') as archive:
        for p in sorted((E/name).rglob('*')):
            if p.is_file() and p.suffix!='.npz': archive.add(p,arcname=str(p.relative_to(E)))
        p=E/(name+'.log')
        if p.exists(): archive.add(p,arcname=p.name)
for source,target in [('parity/summary.json','parity-summary.json'),('candidate-build/build.json','candidate-build.json'),('sanitized-build/build.json','sanitized-build.json'),('screening-plan.json','screening-plan.json'),('validation-notes.json','validation-notes.json'),('memory-followup/summary.json','memory-followup-summary.json'),('memory-followup/plan.json','memory-followup-plan.json')]: shutil.copy2(E/source,R/target)
with tarfile.open(R/'validation-and-reproduction.tar.gz','w:gz') as archive:
    for p in sorted(E.glob('*')):
        if p.is_file() and p.suffix in ('.py','.log','.patch','.json','.txt'):archive.add(p,arcname=p.name)
    for name in ('source','candidate-build','sanitized-build'):
        for p in sorted((E/name).rglob('*')):
            if p.is_file() and p.suffix in ('.py','.cpp','.hpp','.json','.log','.lock','.md'):archive.add(p,arcname=str(p.relative_to(E)))
write(R/'comparisons.json',comparisons)
manifest=dict(external_root=str(E),contract='gambit-fifo-latency-v1',performance_qualification=False,source_variant_count=1,baseline_native_sha256=hashfile(E/'baseline/src/gambit/_factor_cache.cpython-310-darwin.so'),candidate_native_sha256=hashfile(E/'candidate-build/_factor_cache.cpython-310-darwin.so'),reference={'path':'/Users/jkm0607/Projects/gambit-evidence/lat04-2026-09-20/reference-build/fifo-reference'},external_files={},repository_files={})
for p in sorted(E.rglob('*')):
    if p.is_file() and '__pycache__' not in p.parts and p.name not in ('report-draft.md','artifact-audit.json'):
        manifest['external_files'][str(p.relative_to(E))]=dict(bytes=p.stat().st_size,sha256=hashfile(p))
ref=Path(manifest['reference']['path']);manifest['reference']['sha256']=hashfile(ref)
for p in sorted(R.glob('*')):
    if p.is_file():manifest['repository_files'][p.name]=dict(bytes=p.stat().st_size,sha256=hashfile(p))
write(R/'manifest.json',manifest)
print(json.dumps(comparisons,indent=2))
