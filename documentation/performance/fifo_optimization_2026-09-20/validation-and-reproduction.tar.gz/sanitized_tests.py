"""Re-export the injected ASan runtime for supervised child Python processes on macOS."""
import os
import sys
import pytest
os.environ['DYLD_INSERT_LIBRARIES']='/Library/Developer/CommandLineTools/usr/lib/clang/17/lib/darwin/libclang_rt.asan_osx_dynamic.dylib'
sys.exit(pytest.main(['-q','tests/test_top_of_book_backtest.py','tests/test_fifo_backtest.py','tests/test_fifo_parity.py']))
