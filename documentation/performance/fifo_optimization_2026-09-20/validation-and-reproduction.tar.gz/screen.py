"""LAT-05 bounded variant diagnostics; authoritative full screening uses runner CLI."""
import argparse
import json
import sys
from pathlib import Path
sys.path.insert(0, '/Users/jkm0607/Projects/gambit/benchmarks')
from controlled_replay import run_trial, compare_pairs
from replay_contract import workload, write_json
p=argparse.ArgumentParser()
p.add_argument('--output', type=Path, required=True)
p.add_argument('--pairs', type=int, default=3)
p.add_argument('--ticks', type=int, default=100_000_000)
p.add_argument('--chunk', type=int, default=65521)
a=p.parse_args(); a.output.mkdir(parents=True)
spec=workload('fifo-3y-sparse-v1',a.chunk)
plan=dict(pairs=a.pairs,prefix_ticks=a.ticks,workload=spec,hypothesis='specialize and inline validated event traversal; split infrequent rebalance',qualification=False)
write_json(a.output/'plan.json',plan)
trials=[]
for pair in range(a.pairs):
    variants=[('baseline','/Users/jkm0607/Projects/gambit-evidence/lat05-2026-09-20/baseline-python'),('candidate',sys.executable)]
    if pair%2: variants.reverse()
    for label,python in variants:
        trial=run_trial(a.output/f'{pair+1:03d}-{label}',spec,session_id=a.output.name,variant=label,python=python,diagnostic={'prefix_ticks':a.ticks,'instrumentation':'full'})
        trials.append(trial)
        print(json.dumps(dict(pair=pair+1,variant=label,status=trial['status'],measurement=trial['measurement'])),flush=True)
        if trial['status']!='ok': raise RuntimeError(trial)
write_json(a.output/'summary.json',compare_pairs(trials))
