"""Predeclared LAT-05 screening: serial, fresh processes, 30 alternating pairs each."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
root=Path('/Users/jkm0607/Projects/gambit')
evidence=Path(__file__).resolve().parent
deadline=time.monotonic()+600
while not (evidence/'parity/summary.json').exists():
    if time.monotonic()>deadline: raise RuntimeError('independent parity did not finish')
    time.sleep(1)
parity=json.loads((evidence/'parity/summary.json').read_text())
if parity.get('status') != 'exact_trace_match' or len(parity['trials']) != 6: raise RuntimeError(parity)
baseline=evidence/'baseline-python'
build=evidence/'candidate-build/build.json'
commands=[]
for scenario in ('fifo-3y-sparse-v1','fifo-1m-dense-v1','fifo-2m-dense-v1'):
    name=scenario.removeprefix('fifo-').removesuffix('-v1')
    commands.append((name,[sys.executable,str(root/'benchmarks/controlled_replay.py'),'run','--scenario',scenario,'--trials','30','--session-id','lat05-'+name,'--baseline-python',str(baseline),'--build-manifest',str(build),'--output-dir',str(evidence/name)]))
for chunk in (65536,1048576):
    name=f'chunk-{chunk}-prefix'
    commands.append((name,[sys.executable,str(evidence/'screen.py'),'--pairs','30','--chunk',str(chunk),'--output',str(evidence/name)]))
plan=dict(started_at=datetime.now(timezone.utc).isoformat(),commands=commands,source_sha256=hashlib.sha256((root/'src/gambit/cpp/factor_cache/top_of_book_backtest.cpp').read_bytes()).hexdigest(),candidate_sha256=hashlib.sha256((root/'src/gambit/_factor_cache.cpython-310-darwin.so').read_bytes()).hexdigest(),baseline_sha256=hashlib.sha256((evidence/'baseline/src/gambit/_factor_cache.cpython-310-darwin.so').read_bytes()).hexdigest(),qualification=False,control_scope='Full primary and both full dense workloads. Alternative chunks use 100m-event prefixes for timing; full chunks covered by independent parity.')
with (evidence/'screening-plan.json').open('x') as out: json.dump(plan,out,indent=2)
for name,command in commands:
    print('START',name,datetime.now(timezone.utc).isoformat(),flush=True)
    with (evidence/(name+'.log')).open('x') as log:
        result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
    print('END',name,'exit',result.returncode,datetime.now(timezone.utc).isoformat(),flush=True)
    if result.returncode: sys.exit(result.returncode)
print('SCREENING COMPLETE',flush=True)
