"""Summarize the complete, predeclared memory follow-up without dropping outliers."""
import json
from pathlib import Path
import sys
sys.path.insert(0,'/Users/jkm0607/Projects/gambit/benchmarks')
from replay_contract import distribution, EXPECTED
E=Path(__file__).resolve().parent
F=E/'memory-followup'
read=lambda p:json.loads(p.read_text())
normal=read(F/'normal-replication/summary.json')['paired_comparison']
rows=[]
for p in sorted(F.glob('???-*/memory.json')):
    m=read(p);w=read(p.with_name('worker-result.json'));label=p.parent.name.split('-')[1]
    assert w['controls']==EXPECTED['fifo-2m-dense-v1']
    phases={k:next(s for s in m['snapshots'] if s['phase']==k) for k in ('setup','harness','batch','materialize','verify','persist','complete')}
    row=dict(variant=label,directory=p.parent.name,native_sha256=w['identity']['native_extension_sha256'],result_array_bytes=w['resources']['result_array_bytes'],peak_rss_bytes=max(s['high_water_bytes'] for s in m['snapshots']),result_copy_live_delta=phases['verify']['malloc']['size_in_use']-phases['materialize']['malloc']['size_in_use'])
    for phase,s in phases.items():
        row[phase+'_rss_bytes']=s['rss_bytes']
        row[phase+'_live_bytes']=s['malloc']['size_in_use']
        row[phase+'_reserved_bytes']=s['malloc']['size_allocated']
    row['replay_live_delta']=phases['materialize']['malloc']['size_in_use']-phases['harness']['malloc']['size_in_use']
    rows.append(row)
assert len(rows)==60
summary=dict(original_maximum_rss_ratio=154533888/144441344,normal_replication=normal,diagnostic={},rows=rows,qualification=False,timing_usable=False)
for label in ('baseline','candidate'):
    selected=[r for r in rows if r['variant']==label];assert len(selected)==30
    assert len({r['native_sha256'] for r in selected})==1
    stats={k:dict(distribution([r[k] for r in selected]),minimum=min(r[k] for r in selected)) for k in selected[0] if k.endswith(('_bytes','_delta'))}
    summary['diagnostic'][label]=stats
summary['normal_replication_maximum_rss_ratio']=normal['comparisons']['peak_rss_bytes']['candidate']['maximum']/normal['comparisons']['peak_rss_bytes']['baseline']['maximum']
summary['diagnostic_maximum_rss_ratio']=summary['diagnostic']['candidate']['peak_rss_bytes']['maximum']/summary['diagnostic']['baseline']['peak_rss_bytes']['maximum']
with (F/'summary.json').open('x') as out:json.dump(summary,out,indent=2)
print('normal',normal['status'],summary['normal_replication_maximum_rss_ratio'])
print('diagnostic max RSS ratio',summary['diagnostic_maximum_rss_ratio'])
for metric in ('setup_rss_bytes','harness_rss_bytes','batch_rss_bytes','materialize_rss_bytes','verify_rss_bytes','peak_rss_bytes','harness_live_bytes','materialize_live_bytes','verify_live_bytes','result_copy_live_delta','replay_live_delta'):
    print(metric,{label:summary['diagnostic'][label][metric] for label in ('baseline','candidate')})
