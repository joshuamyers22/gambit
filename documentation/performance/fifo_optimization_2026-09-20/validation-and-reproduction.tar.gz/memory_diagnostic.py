"""LAT-05 follow-up for the retained dense maximum-RSS outlier; never timing evidence."""
import ctypes
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
import time
ROOT=Path('/Users/jkm0607/Projects/gambit')
E=Path(__file__).resolve().parent

def worker(output):
    sys.path.insert(0,str(ROOT/'benchmarks'))
    import psutil
    import controlled_replay as runner
    from replay_contract import workload, write_json
    # Layout and NULL-zone aggregation read from the local macOS SDK malloc/malloc.h.
    class Statistics(ctypes.Structure):
        _fields_=[('blocks_in_use',ctypes.c_uint),('size_in_use',ctypes.c_size_t),('max_size_in_use',ctypes.c_size_t),('size_allocated',ctypes.c_size_t)]
    libc=ctypes.CDLL('/usr/lib/libSystem.B.dylib')
    libc.malloc_zone_statistics.argtypes=[ctypes.c_void_p,ctypes.POINTER(Statistics)]
    libc.malloc_zone_statistics.restype=None
    process=psutil.Process()
    snapshots=[]
    def emit(phase,**extra):
        stats=Statistics();libc.malloc_zone_statistics(None,ctypes.byref(stats))
        snapshots.append(dict(phase=phase,processed=extra.get('processed'),rss_bytes=process.memory_info().rss,high_water_bytes=runner.rss_bytes(),malloc={name:getattr(stats,name) for name,_ in Statistics._fields_}))
    runner.emit=emit
    output.mkdir()
    runner.run_worker(dict(workload=workload('fifo-2m-dense-v1'),diagnostic={'instrumentation':'full'}),output)
    write_json(output/'memory.json',dict(performance_qualification=False,timing_usable=False,probes='RSS plus all-zone malloc statistics at existing protocol phases',snapshots=snapshots))

if len(sys.argv)>1 and sys.argv[1]=='_worker':
    worker(Path(sys.argv[2]));sys.exit()

output=E/'memory-followup';output.mkdir(exist_ok=False)
plan=dict(created_at=datetime.now(timezone.utc).isoformat(),reason='Original 2m-dense candidate trial 008 maximum RSS 154533888 bytes; baseline campaign maximum 144441344 bytes (+6.99%), despite p95 ratio 1.0116. Investigate rather than omit it.',normal_replication_pairs=30,memory_diagnostic_pairs=30,workload='complete fifo-2m-dense-v1',qualification=False,policy='Retain original and every follow-up observation. No selective extension; diagnostics are not timing acceptance.')
(output/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
deadline=time.monotonic()+2400
while 'SCREENING COMPLETE' not in (E/'screening.log').read_text():
    if time.monotonic()>deadline:raise RuntimeError('screening did not complete')
    time.sleep(1)
command=[sys.executable,str(ROOT/'benchmarks/controlled_replay.py'),'run','--scenario','fifo-2m-dense-v1','--trials','30','--session-id','lat05-2m-dense-memory-followup','--baseline-python',str(E/'baseline-python'),'--build-manifest',str(E/'candidate-build/build.json'),'--output-dir',str(output/'normal-replication')]
(output/'replication-command.json').write_text(json.dumps(command,indent=2)+'\n')
with (output/'normal-replication.log').open('x') as stream:subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,check=True)
print('Normal replication complete',flush=True)
for pair in range(30):
    variants=[('baseline',str(E/'baseline-python')),('candidate',sys.executable)]
    if pair%2:variants.reverse()
    for label,python in variants:
        destination=output/f'{pair+1:03d}-{label}'
        with (output/f'{pair+1:03d}-{label}.log').open('x') as stream:
            subprocess.run([python,str(Path(__file__).resolve()),'_worker',str(destination)],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,timeout=30,check=True)
    print('Memory pair',pair+1,'complete',flush=True)
print('MEMORY FOLLOW-UP COMPLETE',flush=True)
